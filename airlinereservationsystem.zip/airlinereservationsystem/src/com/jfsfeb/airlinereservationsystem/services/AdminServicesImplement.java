package com.jfsfeb.airlinereservationsystem.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystem.dao.*;
import com.jfsfeb.airlinereservationsystem.dto.AdminBean;
import com.jfsfeb.airlinereservationsystem.dto.FlightBean;
import com.jfsfeb.airlinereservationsystem.validations.Validation;

public class AdminServicesImplement implements AdminServices {

	Validation valid = new Validation();
	AdminDAO dao = new AdminDAOImplement();

	@Override
	public boolean adminRegistration(AdminBean bean) {

		return dao.adminRegistration(bean);
	}

	@Override
	public AdminBean adminLogin(String email, String adminPass) {

		if (valid.validateEmail(email)) {
			if (valid.validatePassword(adminPass)) {
				return dao.adminLogin(email, adminPass);
			}
		}
		return null;
	}

	@Override
	public boolean addFlights(FlightBean flight) {

		return dao.addFlights(flight);
	}

	@Override
	public boolean removeFlight(int flightId) {

		return dao.removeFlight(flightId);
	}

	@Override
	public List<FlightBean> searchFlightBySource(String source) {

		return dao.searchFlightBySource(source);
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depature) {

		return dao.searchFlightByDepature(depature);
	}

	@Override
	public List<FlightBean> getFlightDetails() {

		return dao.getFlightDetails();
	}

}