package com.jfsfeb.airlinereservationsystemhibernate.dao;

import java.util.List;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.StatusBean;

public interface UserDAO {

	List<FlightBean> searchFlightBySource(String sourcePoint);

	List<FlightBean> searchFlightByDepature(String depaturePoint);

	List<FlightBean> getFlightDetails();

	StatusBean flightBookingStatus(StatusBean status);

	List<FlightBean> searchWithSourceDepature(String sourcePoint, String depaturePoint);

	boolean cancelFlightTicket(int ticketId);

	List<StatusBean> getFlightTicketInfo(int userId);
}