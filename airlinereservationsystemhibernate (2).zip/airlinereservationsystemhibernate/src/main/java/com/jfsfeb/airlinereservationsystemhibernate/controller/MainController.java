package com.jfsfeb.airlinereservationsystemhibernate.controller;

public class MainController {
      public static void main(String[] args) {
    	  Controller.controls();
	}
}
