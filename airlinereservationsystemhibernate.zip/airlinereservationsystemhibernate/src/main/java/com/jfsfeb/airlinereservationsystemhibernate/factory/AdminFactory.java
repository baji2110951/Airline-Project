package com.jfsfeb.airlinereservationsystemhibernate.factory;

import com.jfsfeb.airlinereservationsystemhibernate.dao.*;
import com.jfsfeb.airlinereservationsystemhibernate.services.*;

public class AdminFactory {

	private AdminFactory() {
	}

	public static AdminDAO getAdminDAOImplementInstance() {
		AdminDAO daoAdmin = new AdminDAOImplement();
		return daoAdmin;
	}

	public static AdminServices getAdminServicesImplementInstance() {
		AdminServices serviceAdmin = new AdminServicesImplement();
		return serviceAdmin;
	}
}
