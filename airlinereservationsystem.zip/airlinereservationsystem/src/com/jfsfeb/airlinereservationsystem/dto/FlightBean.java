package com.jfsfeb.airlinereservationsystem.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import lombok.Data;

@Data
@SuppressWarnings("serial")
public class FlightBean implements Serializable {
	private int flightId;
	private String flightName;
	private String sourcePoint;
	private String depaturePoint;
	private int totalSeatsAvailable;
	private LocalDateTime arrivalDateTime;
	private LocalDateTime departureDateTime;

}