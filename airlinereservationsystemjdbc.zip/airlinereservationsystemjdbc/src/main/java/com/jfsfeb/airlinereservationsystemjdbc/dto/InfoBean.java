package com.jfsfeb.airlinereservationsystemjdbc.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;

@Data
@SuppressWarnings("serial")
public class InfoBean implements Serializable {

	private int id;
	private String name;
	private String email;
	@ToString.Exclude
	private String password;
	private long mobileNum;
	private String role;

}
