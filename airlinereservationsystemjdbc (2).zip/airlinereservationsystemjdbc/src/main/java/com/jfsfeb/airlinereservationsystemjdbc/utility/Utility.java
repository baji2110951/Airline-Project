package com.jfsfeb.airlinereservationsystemjdbc.utility;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class Utility {
	public Connection getConnection() {
		Connection connection = null;
		try {
			FileInputStream input = new FileInputStream("airlinereservation.properties");
			Properties pro = new Properties();
			pro.load(input);
			Class.forName("com.mysql.jdbc.Driver");

			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/airlinereservation","root","baji21109");

			return connection;
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}

	public String getQuery(String enteredQuery) {
		String query = null;
		FileInputStream input;
		try {
			input = new FileInputStream("airlinereservation.properties");
			Properties pro = new Properties();
			pro.load(input);
			query = pro.getProperty(enteredQuery);

			return query;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}
}