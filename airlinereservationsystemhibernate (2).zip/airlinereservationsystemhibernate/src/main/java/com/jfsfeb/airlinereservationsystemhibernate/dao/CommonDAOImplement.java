package com.jfsfeb.airlinereservationsystemhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemhibernate.exception.AirlineException;

public class CommonDAOImplement implements CommonDAO {

	EntityManagerFactory emf = null;

	@Override
	public boolean registration(InfoBean admin) {
		EntityManager manager = null;
		EntityTransaction trans = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();
			manager.persist(admin);
			trans.commit();
			return true;
		} catch (Exception e) {
			trans.rollback();
			throw new AirlineException("Unable to add AdMIN or USER");
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public InfoBean login(String email, String password) {
		EntityManager manager = null;
		emf = Persistence.createEntityManagerFactory("TestPersistence");
		manager = emf.createEntityManager();
		String jpql = "select u from  InfoBean u where u.email = :email and u.password =:password";
		TypedQuery<InfoBean> query = manager.createQuery(jpql, InfoBean.class);
		query.setParameter("email", email);
		query.setParameter("password", password);
		try {
			return query.getSingleResult();
		} catch (Exception e) {
			throw new AirlineException("Invalid Login Credentials, Please Enter Correctly");
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public List<FlightBean> getFlightDetails() {
		EntityManager manager = null;
		emf = Persistence.createEntityManagerFactory("TestPersistence");
		manager = emf.createEntityManager();
		String jpql = "select f from FlightBean f";
		TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
		List<FlightBean> list = query.getResultList();
		manager.close();
		emf.close();
		return list;
	}

	@Override
	public List<FlightBean> searchWithSourceDepature(String sourcePoint, String departurePoint) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select e from FlightBean e where e.sourcePoint=:sourcePoint and e.departurePoint=:departurePoint";
			TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
			query.setParameter("sourcePoint", sourcePoint);
			query.setParameter("departurePoint", departurePoint);
			List<FlightBean> list = query.getResultList();
			for (int i = 0; i < list.size() - 1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
