package com.jfsfeb.airlinereservationsystemjdbc.dao;

import java.util.List;

import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.StatusBean;

public interface AdminDAO {

	boolean addFlights(FlightBean flightDetails);

	boolean removeFlight(int flightId);

	List<FlightBean> searchFlightBySource(String sourcePoint);

	List<FlightBean> searchFlightByDepature(String depaturePoint);

	List<FlightBean> getFlightDetails();

	List<StatusBean> getFlightBookingStatus();
}
