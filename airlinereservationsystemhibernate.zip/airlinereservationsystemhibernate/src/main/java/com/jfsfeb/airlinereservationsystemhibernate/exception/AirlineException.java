package com.jfsfeb.airlinereservationsystemhibernate.exception;

@SuppressWarnings("serial")
public class AirlineException extends RuntimeException {
	public AirlineException(String msg) {
		super(msg);
	}
}
