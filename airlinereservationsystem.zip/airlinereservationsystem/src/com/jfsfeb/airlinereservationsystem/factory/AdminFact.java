package com.jfsfeb.airlinereservationsystem.factory;

import com.jfsfeb.airlinereservationsystem.dao.*;
import com.jfsfeb.airlinereservationsystem.services.*;

public class AdminFact {

	private AdminFact() {
	}

	public static AdminDAO getAdminDAOImplementInstance() {
		AdminDAO daoAdmin = new AdminDAOImplement();
		return daoAdmin;
	}

	public static AdminServices getAdminServicesImplementInstance() {
		AdminServices serviceAdmin = new AdminServicesImplement();
		return serviceAdmin;
	}
}
