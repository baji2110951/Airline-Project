package com.jfsfeb.airlinereservationsystemhibernate.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table (name="flight_bean")
@SuppressWarnings("serial")
public class FlightBean implements Serializable {
	@Id
	@Column
	private int flightId;
	@Column
	private String flightName;
	@Column
	private String sourcePoint;
	@Column
	private String departurePoint;
	@Column
	private int totalSeatsAvailable;
	@Column
	private LocalDate arrivalDate;
	@Column
	private LocalTime arrivalTimings;
	@Column
	private LocalDate departureDate;
	@Column
	private LocalTime departureTimings;
}