
package com.jfsfeb.airlinereservationsystemhibernate.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemhibernate.exception.AirlineException;
import com.jfsfeb.airlinereservationsystemhibernate.factory.CommonFactory;
import com.jfsfeb.airlinereservationsystemhibernate.services.CommonServices;

import lombok.extern.log4j.Log4j;

@Log4j
public class Controller {
	public static void controls() {

		String validateName = null;
		long validateMobile = 0;
		String validateEmail = null;
		String validatePassword = null;
		String role = null;
		String email = null;
		String password = null;

		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		CommonServices service = CommonFactory.getCommonServicesImplementInstance();
		do {
			try {

				log.info("........................................................................................");
				log.info("             --------Welcome To Airline Reservation System---------              ");

				log.info(".........................................................................................");
				log.info("1. View All Flights");
				log.info("2.Search Flight By SourcePoint And DeparturePoint");
				log.info("3.Already Registered ! Login Here");
				log.info("4.New User");
                 log.info("..........................................................................................");
				int a = scan.nextInt();
				switch (a) {
				case 1:
					try {
						log.info("                 ALL FLIGHT DETAILS                       ");
						log.info("..................................................................");
						List<FlightBean> values = service.getFlightDetails();
						log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s", "FlightId",
								"FlightName", "SourcePoint", "DestinationPoint", "totalSeatAvailable", "ArrivalDate",
								"ArraivalTime", "DepartureDate", "DepartureTime"));
						log.info("....................................................................");
						for (FlightBean flightBean : values) {
							if (flightBean != null) {
								log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
										flightBean.getFlightId(), flightBean.getFlightName(),
										flightBean.getSourcePoint(), flightBean.getDeparturePoint(),
										flightBean.getTotalSeatsAvailable(), flightBean.getArrivalDate(),
										flightBean.getArrivalTimings(), flightBean.getDepartureDate(),
										flightBean.getDepartureTimings()));
								log.info("...............................................................");
							} else {
								log.info("No Flight are found with th Flight Details");
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 2:

					
					try {
						log.info("Enter flight SourcePoint : ");
						String source = scan.next();
						log.info("Search flight by Destination : ");
						String depature = scan.next();
						FlightBean bean = new FlightBean();
						bean.setSourcePoint(source);
						bean.setDeparturePoint(depature);
						List<FlightBean> flightSourceToDestination = service.searchWithSourceDepature(source, depature);
						log.info("...............................................................................");
						log.info(String.format("%-10s %-10s %-13s %-15s %-20s %-20s %s", "FlightId", "FlightName",
								"Source", "Destination", "TotalSeatsAvailable", "ArraivalTime", "DepartureTime"));
						log.info("................................................................................");
						for (FlightBean flight : flightSourceToDestination) {
							if (flight != null) {
								log.info(String.format("%-10s %-10s %-13s %-15s %-20s %-20s %s", flight.getFlightId(),
										flight.getFlightName(), flight.getSourcePoint(), flight.getDeparturePoint(),
										flight.getTotalSeatsAvailable(), flight.getArrivalTimings(),
										flight.getDepartureTimings()));
							} else {
								log.info("No Flights are available with this Destination");
							}
						}
					} catch (Exception e) {
						log.error(e.getMessage());
					}
					break;

				case 3:
					log.info("                LOG IN HERE !                   ");
					log.info(".....................................................");
					log.info("Enter registered email to login : ");
					email = scan.next();
					log.info("Enter registered Password to login : ");
					password = scan.next();

					try {
						// log.info("Enter your Role");
						// role = scan.next();
						// InfoBean bean1 = new InfoBean();
						// bean1.setRole(role);
						InfoBean infoBean = service.login(email, password);
						if (infoBean != null) {
							String adminRole = "admin";
							String userRole = "user";
							if (infoBean.getRole().equals(adminRole)) {
								AdminController.adminControls();
							} else if (infoBean.getRole().equals(userRole)) {
								UserController.userControls();
							}
						} else {
							log.info("null values not allowed ");
						}
					} catch (AirlineException e) {
						e.printStackTrace();
						log.info(e.getMessage());
					}
					break;

				case 4:
					try {
						log.info("                  NEW USER                          ");
						log.info(".......................................................");

						log.info("Enter Name to Register : ");
						validateName = scan.next();
						log.info("Enter MobileNumber to Register : ");
						validateMobile = scan.nextLong();
						log.info("Enter Email to Register : ");
						validateEmail = scan.next();
						log.info("Enter Password :");
						validatePassword = scan.next();

						role = "user";
						int userId = (int) (Math.random() * 10000);
						if (userId <= 1000) {
							userId = userId + 1000;
						}

						InfoBean bean = new InfoBean();
						bean.setId(userId);
						bean.setName(validateName);
						bean.setMobileNum(validateMobile);
						bean.setEmail(validateEmail);
						bean.setPassword(validatePassword);
						bean.setRole(role);

						boolean check = service.registration(bean);
						if (check) {
							log.info("You have registered Successfully");
						} else {
							log.info("Already registered");
						}
						break;
					} catch (InputMismatchException e) {
						log.error("Invalid entry ");
						scan.next();
						break;
					} catch (AirlineException e) {
						log.info(e.getMessage());
						break;
					}

				default:
					log.info("Invalid Choice");
					log.error("Choice must be 1 or 2 or 3 or 4");
					break;
				}
			} catch (InputMismatchException e) {
				log.error("Invalid entry please provide 1 or 2 or 3 or 4");
				scan.nextLine();
			} catch (AirlineException e) {
				log.info(e.getMessage());

			} catch (Exception e) {
				e.printStackTrace();
				log.error("Invalid Credentials");
			}

		} while (true);
	}
}