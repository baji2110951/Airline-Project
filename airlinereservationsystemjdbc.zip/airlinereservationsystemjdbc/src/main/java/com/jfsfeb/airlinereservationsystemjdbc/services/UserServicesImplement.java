package com.jfsfeb.airlinereservationsystemjdbc.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystemjdbc.dao.UserDAO;
import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemjdbc.factory.UserFact;
import com.jfsfeb.airlinereservationsystemjdbc.validations.Validation;

public class UserServicesImplement implements UserServices {

	Validation valid = new Validation();
	UserDAO dao = UserFact.getUserDAOImplementInstance();

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {

		return dao.searchFlightBySource(sourcePoint);
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depaturePoint) {

		return dao.searchFlightByDepature(depaturePoint);
	}

	@Override
	public List<FlightBean> getFlightDetails() {

		return dao.getFlightDetails();
	}

	@Override
	public StatusBean flightBookingStatus(StatusBean bean) {

		return dao.flightBookingStatus(bean);
	}

	@Override
	public List<FlightBean> searchWithSourceDepature(String sourcePoint, String depaturePoint) {

		if (valid.validateSourcePoint(sourcePoint)) {
			if (valid.validateDepaturePoint(depaturePoint)) {
				return dao.searchWithSourceDepature(sourcePoint, depaturePoint);
			}
		}
		return null;

	}

	@Override
	public boolean cancelFlightTicket(int flightBookingId) {
		if (valid.validateId(flightBookingId)) {
			return dao.cancelFlightTicket(flightBookingId);
		}
		return false;
	}

	@Override
	public List<StatusBean> getFlightTicketInfo(int userId) {
		if (valid.validateId(userId)) {
			return dao.getFlightTicketInfo(userId);
		}
		return null;
	}

}