package com.jfsfeb.airlinereservationsystemjdbc.factory;

import com.jfsfeb.airlinereservationsystemjdbc.dao.CommonDAO;
import com.jfsfeb.airlinereservationsystemjdbc.dao.CommonDAOImplement;
import com.jfsfeb.airlinereservationsystemjdbc.services.CommonServices;
import com.jfsfeb.airlinereservationsystemjdbc.services.CommonServicesImplement;

public class CommonFactory {

	private CommonFactory() {
	}

	public static CommonDAO getCommonDAOImplementInstance() {
		CommonDAO dao = new CommonDAOImplement();
		return dao;
	}
	
	public static CommonServices getCommonServicesImplementInstance() {
	
		CommonServices services=new CommonServicesImplement();
		return services;
	}
}
