package com.jfsfeb.airlinereservationsystemhibernate.factory;

import com.jfsfeb.airlinereservationsystemhibernate.dao.*;
import com.jfsfeb.airlinereservationsystemhibernate.services.*;

public class UserFactory {

	private UserFactory() {
	}

	public static UserDAO getUserDAOImplementInstance() {
		UserDAO daoUser = new UserDAOImplement();
		return daoUser;
	}

	public static UserServices getUserServicesImplementInstance() {
		UserServices serviceUser = new UserServicesImplement();
		return serviceUser;
	}
}