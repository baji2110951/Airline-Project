package com.jfsfeb.airlinereservationsystemhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemhibernate.exception.AirlineException;

public class UserDAOImplement implements UserDAO {

	EntityManagerFactory emf = null;

	@Override
	public boolean cancelFlightTicket(int bookingId) {
		EntityManager manager = null;
		EntityTransaction trans = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();
			StatusBean status = manager.find(StatusBean.class, bookingId);
			manager.remove(status);
			trans.commit();
			return true;
		} catch (Exception e) {
			
			trans.rollback();
			throw new AirlineException("Flight Ticket with this Id is not  Deleted");
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public List<StatusBean> getFlightTicketInfo(int userId) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select s from StatusBean s where s.id=:id";
			TypedQuery<StatusBean> query = manager.createQuery(jpql, StatusBean.class);
			query.setParameter("id", userId);
			List<StatusBean> list = query.getResultList();
			for (int i = 0; i < list.size() - 1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select s from FlightBean s where s.sourcePoint=:sourcePoint";
			TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
			query.setParameter("sourcePoint", sourcePoint);
			List<FlightBean> list = query.getResultList();
			for (int i = 0; i < list.size() - 1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();

		}

		return null;
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String departurePoint) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select f from FlightBean f where f.departurePoint=:departurePoint";
			TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
			query.setParameter("departurePoint", departurePoint);
			List<FlightBean> list = query.getResultList();
			for (int i = 0; i < list.size() - 1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();

		}

		return null;
	}

	@Override
	public List<FlightBean> getFlightDetails() {
		EntityManager manager = null;
		emf = Persistence.createEntityManagerFactory("TestPersistence");
		manager = emf.createEntityManager();
		String jpql = "select f from FlightBean f";
		TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
		List<FlightBean> list = query.getResultList();
		manager.close();
		emf.close();
		return list;
	}

	@Override
	public List<FlightBean> searchWithSourceDepature(String sourcePoint, String departurePoint) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select d from FlightBean d where d.sourcePoint=:sourcePoint and d.departurePoint=:departurePoint";
			TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
			query.setParameter("sourcePoint", sourcePoint);
			query.setParameter("departurePoint", departurePoint);
			List<FlightBean> list = query.getResultList();
			for (int i = 0; i < list.size() - 1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public StatusBean flightBookingStatus(StatusBean status) {

		EntityManager manager = null;
		EntityTransaction trans = null;  
		FlightBean flight=new FlightBean();
		InfoBean user=new InfoBean();
		int flightId=0;
		int userId=0;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();
			flight = manager.find(FlightBean.class, status.getFlightId());

			if (flight != null) {
				flightId=flight.getFlightId();
				trans.commit();
				if(flightId==status.getFlightId()) {
					trans.begin();
					user = manager.find(InfoBean.class, status.getId());
					if(user!=null) {
						userId=user.getId();
						trans.commit();
						if(userId==status.getId()) {
							trans.begin();
							manager.persist(status);
							trans.commit();
							return status;
						}
					}else {
						throw new AirlineException("Invalid Request, User ID Not Found");
					}
				}
				
			} else {
				throw new AirlineException("Invalid Request, Flight ID Not Found");
			}
		} catch (AirlineException e) {
			throw new AirlineException(e.getMessage());
		} finally {
			manager.close();
			emf.close();
		}
		
		return null;
	}

}