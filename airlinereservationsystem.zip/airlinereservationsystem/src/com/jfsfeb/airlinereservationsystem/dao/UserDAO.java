package com.jfsfeb.airlinereservationsystem.dao;

import java.util.List;

import com.jfsfeb.airlinereservationsystem.dto.FlightBean;
import com.jfsfeb.airlinereservationsystem.dto.UserBean;

public interface UserDAO {

	boolean userRegistration(UserBean bean);

	UserBean userLogin(String emailId, String userPass);

	List<FlightBean> searchFlightBySource(String sourcePoint);

	List<FlightBean> searchFlightByDepature(String depaturePoint);

	List<FlightBean> getFlightDetails();

}