package com.jfsfeb.airlinereservationsystem.dao;

import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.airlinereservationsystem.dto.AdminBean;
import com.jfsfeb.airlinereservationsystem.dto.FlightBean;
import com.jfsfeb.airlinereservationsystem.exception.AirlineException;
import com.jfsfeb.airlinereservationsystem.repository.AirlineDB;

public class AdminDAOImplement implements AdminDAO {

	@Override
	public boolean adminRegistration(AdminBean bean) {

		for (AdminBean a1 : AirlineDB.adminD) {
			if ((a1.getEmail()).equals(bean.getEmail())) {
				return false;
			}
		}
		AirlineDB.adminD.add(bean);
		return true;
	}

	@Override
	public AdminBean adminLogin(String email, String adminPass) {

		for (AdminBean a2 : AirlineDB.adminD) {
			if ((a2.getEmail().equals(email)) && (a2.getAdminPass().equals(adminPass))) {
				return a2;
			}
		}
		throw new AirlineException("Please Enter Registered Email and Password");
	}

	@Override
	public boolean addFlights(FlightBean flightDetails) {

		for (FlightBean b : AirlineDB.flightD) {
			if (b.getFlightId() == flightDetails.getFlightId()) {
				return false;
			}
		}
		AirlineDB.flightD.add(flightDetails);
		return true;
	}

	@Override
	public boolean removeFlight(int flightId) {

		boolean status = false;
		for (int i = 0; i <= AirlineDB.flightD.size() - 1; i++) {
			FlightBean flight = AirlineDB.flightD.get(i);
			int id = flight.getFlightId();
			if (flightId == id) {
				status = true;
				AirlineDB.flightD.remove(i);
				break;
			}
		}
		return status;
	}

	@Override
	public List<FlightBean> searchFlightBySource(String source) {

		List<FlightBean> searchData = new ArrayList<FlightBean>();
		for (int i = 0; i <= AirlineDB.flightD.size() - 1; i++) {
			FlightBean flight = AirlineDB.flightD.get(i);
			String retrievedFSource = flight.getSourcePoint();
			if (source.equals(retrievedFSource)) {
				searchData.add(flight);
			}
		}
		if (searchData.size() == 0) {
			throw new AirlineException("Flight was not found");
		} else {
			return searchData;
		}
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depature) {

		List<FlightBean> searchData = new ArrayList<FlightBean>();
		for (int i = 0; i <= AirlineDB.flightD.size() - 1; i++) {
			FlightBean flight = AirlineDB.flightD.get(i);
			String destination = flight.getDepaturePoint();
			if (depature.equals(destination)) {
				searchData.add(flight);
			}
		}
		if (searchData.size() == 0) {
			throw new AirlineException("Flight was not found");
		} else {
			return searchData;
		}
	}

	@Override
	public List<FlightBean> getFlightDetails() {
	
		return AirlineDB.flightD;
	}

}