package com.jfsfeb.airlinereservationsystemhibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@SuppressWarnings("serial")
@Data
@Entity
@Table (name="status_bean")
public class StatusBean implements Serializable{
	private FlightBean flightBeans;
	private InfoBean userBeans;
	@Id
	@Column
	private int id;
	@Column
	private int flightId;
    @Column
	private int bookingId;
	@Column
    private int totalSeatsBooked;
}
