package com.jfsfeb.airlinereservationsystemjdbc.factory;

import com.jfsfeb.airlinereservationsystemjdbc.dao.*;
import com.jfsfeb.airlinereservationsystemjdbc.services.*;

public class AdminFact {

	private AdminFact() {
	}

	public static AdminDAO getAdminDAOImplementInstance() {
		AdminDAO daoAdmin = new AdminDAOImplement();
		return daoAdmin;
	}

	public static AdminServices getAdminServicesImplementInstance() {
		AdminServices serviceAdmin = new AdminServicesImplement();
		return serviceAdmin;
	}
}
