package com.jfsfebi.airlinereservationsystem.controller;

public class MainController {
      public static void main(String[] args) {
    	  Controller.controls();
	}
}
