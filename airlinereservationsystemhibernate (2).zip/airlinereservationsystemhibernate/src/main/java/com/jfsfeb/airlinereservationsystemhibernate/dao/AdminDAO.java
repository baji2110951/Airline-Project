package com.jfsfeb.airlinereservationsystemhibernate.dao;

import java.util.List;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.StatusBean;

public interface AdminDAO {

	boolean addingFlights(FlightBean flight);

	boolean removeingFlight(int flightId);

	List<FlightBean> searchFlightBySource(String sourcePoint);

	List<FlightBean> searchFlightByDepature(String depaturePoint);

	List<FlightBean> getFlightDetails();

	List<StatusBean> getFlightBookingStatus();

	
}
