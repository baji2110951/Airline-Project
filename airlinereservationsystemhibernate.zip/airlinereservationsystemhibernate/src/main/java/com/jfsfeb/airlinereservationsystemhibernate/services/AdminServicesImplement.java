package com.jfsfeb.airlinereservationsystemhibernate.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystemhibernate.dao.AdminDAO;
import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemhibernate.exception.AirlineException;
import com.jfsfeb.airlinereservationsystemhibernate.factory.AdminFactory;
import com.jfsfeb.airlinereservationsystemhibernate.validations.Validation;

public class AdminServicesImplement implements AdminServices {

	Validation valid = new Validation();
	AdminDAO dao = AdminFactory.getAdminDAOImplementInstance();
	
	

	@Override
	public boolean addFlights(FlightBean flight) {
		if (valid.validateId(flight.getFlightId())) {
			if (valid.validateName(flight.getFlightName())) {
				if (valid.validateSourcePoint(flight.getSourcePoint())) {
					if (valid.validateDepaturePoint(flight.getDeparturePoint())) {
						return dao.addingFlights(flight);
					}
				}
			}
		}

		throw new AirlineException("Enter Valid  Details");
	}

	@Override
	public boolean removeFlight(int flightId) {
		if (valid.validateId(flightId)) {
			return dao.removeingFlight(flightId);
		}
		return false;
	}

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {
		if (valid.validateSourcePoint(sourcePoint)) {
			return dao.searchFlightBySource(sourcePoint);
		}
		return null;

	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depaturePoint) {
		if (valid.validateDepaturePoint(depaturePoint)) {
			return dao.searchFlightByDepature(depaturePoint);
		}
		return null;
	}

	@Override
	public List<FlightBean> getFlightDetails() {

		return dao.getFlightDetails();
	}

	@Override
	public List<StatusBean> getFlightBookingStatus() {

		return dao.getFlightBookingStatus();
	}

}