package com.jfsfeb.airlinereservationsystem.factory;

import com.jfsfeb.airlinereservationsystem.dao.*;
import com.jfsfeb.airlinereservationsystem.services.*;

public class UserFact {

	private UserFact() {
	}

	public static UserDAO getUserDAOImplementInstance() {
		UserDAO daoUser = new UserDAOImplement();
		return daoUser;
	}

	public static UserServices getUserServicesImplementInstance() {
		UserServices serviceUser = new UserServicesImplement();
		return serviceUser;
	}
}