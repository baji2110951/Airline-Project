package com.jfsfeb.airlinereservationsystemhibernate.factory;

import com.jfsfeb.airlinereservationsystemhibernate.dao.CommonDAO;
import com.jfsfeb.airlinereservationsystemhibernate.dao.CommonDAOImplement;
import com.jfsfeb.airlinereservationsystemhibernate.services.CommonServices;
import com.jfsfeb.airlinereservationsystemhibernate.services.CommonServicesImplement;

public class CommonFactory {

	private CommonFactory() {
	}

	public static CommonDAO getCommonDAOImplementInstance() {
		CommonDAO daoCommon = new CommonDAOImplement();
		return daoCommon;
	}

	public static CommonServices getCommonServicesImplementInstance() {
		CommonServices serviceCommon = new CommonServicesImplement();
		return serviceCommon;
	}
}
