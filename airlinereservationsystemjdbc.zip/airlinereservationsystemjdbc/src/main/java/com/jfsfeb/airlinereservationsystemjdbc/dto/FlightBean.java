package com.jfsfeb.airlinereservationsystemjdbc.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

import lombok.Data;

@Data
@SuppressWarnings("serial")
public class FlightBean implements Serializable {
	private int flightId;
	private String flightName;
	private String sourcePoint;
	private String departurePoint;
	private int totalSeatsAvailable;
	private LocalDate arrivalDate;
	private LocalTime arrivalTimings;
	private LocalDate departureDate;
	private LocalTime departureTimings;
}