package com.jfsfeb.airlinereservationsystemjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemjdbc.exception.AirlineException;
import com.jfsfeb.airlinereservationsystemjdbc.utility.Utility;

public class UserDAOImplement implements UserDAO {
	Utility link = new Utility();

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {
		FlightBean flight = null;
		List<FlightBean> list = new ArrayList<FlightBean>();
		try (Connection connection = link.getConnection();
				PreparedStatement prepst = connection.prepareStatement(link.getQuery("flightBySource"));) {
			prepst.setString(1, sourcePoint);
			try (ResultSet result = prepst.executeQuery();) {
				if (result.next()) {
					flight = new FlightBean();
					flight.setFlightId(result.getInt("flightId"));
					flight.setFlightName(result.getString("flightName"));
					flight.setSourcePoint(result.getString("sourcePoint"));
					flight.setDeparturePoint(result.getString("departurePoint"));
					flight.setTotalSeatsAvailable(result.getInt("totalSeatsAvailable"));
					flight.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
					flight.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
					flight.setDepartureDate(result.getDate("departureDate").toLocalDate());
					flight.setDepartureTimings(result.getTime("departureTimings").toLocalTime());
					;
					list.add(flight);
					return list;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		}
		throw new AirlineException("Flight is Not Found");
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depaturePoint) {
		FlightBean flight = null;
		List<FlightBean> list = new ArrayList<FlightBean>();
		try (Connection connection = link.getConnection();
				PreparedStatement prepst = connection.prepareStatement(link.getQuery("flightByDeparture"));) {
			prepst.setString(1, depaturePoint);
			try (ResultSet result = prepst.executeQuery();) {
				if (result.next()) {
					flight = new FlightBean();
					flight.setFlightId(result.getInt("flightId"));
					flight.setFlightName(result.getString("flightName"));
					flight.setSourcePoint(result.getString("sourcePoint"));
					flight.setDeparturePoint(result.getString("departurePoint"));
					flight.setTotalSeatsAvailable(result.getInt("totalSeatsAvailable"));
					flight.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
					flight.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
					flight.setDepartureDate(result.getDate("departureDate").toLocalDate());
					flight.setDepartureTimings(result.getTime("departureTimings").toLocalTime());
					list.add(flight);
					return list;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		}
		throw new AirlineException("Flight is Not Found");
	}

	@Override
	public List<FlightBean> getFlightDetails() {
		List<FlightBean> list = new LinkedList<FlightBean>();
		try (Connection connection = link.getConnection();
				Statement st = connection.createStatement();
				ResultSet result = st.executeQuery(link.getQuery("allFlights"))) {
			while (result.next()) {
				FlightBean info = new FlightBean();
				info.setFlightId(result.getInt("flightId"));
				info.setFlightName(result.getString("flightName"));
				info.setSourcePoint(result.getString("sourcePoint"));
				info.setDeparturePoint(result.getString("departurePoint"));
				info.setTotalSeatsAvailable(result.getInt("totalSeatsAvailable"));
				info.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
				info.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
				info.setDepartureDate(result.getDate("departureDate").toLocalDate());
				info.setDepartureTimings(result.getTime("departureTimings").toLocalTime());

				list.add(info);
			}
			if (list.isEmpty()) {
				throw new AirlineException("No Flight Present in the Airline");
			} else {
				return list;
			}
		} catch (Exception e) {
			throw new AirlineException(e.getMessage());
		}
	}

	@Override
	public List<FlightBean> searchWithSourceDepature(String sourcePoint, String depaturePoint) {
		FlightBean flight = null;
		List<FlightBean> list = new ArrayList<FlightBean>();
		try (Connection connection = link.getConnection();
				PreparedStatement prepst = connection.prepareStatement(link.getQuery("flightBySourceDeparture"));) {
			prepst.setString(1, sourcePoint);
			prepst.setString(2, depaturePoint);
			try (ResultSet result = prepst.executeQuery();) {
				if (result.next()) {
					flight = new FlightBean();
					flight.setFlightId(result.getInt("flightId"));
					flight.setFlightName(result.getString("flightName"));
					flight.setSourcePoint(result.getString("sourcePoint"));
					flight.setDeparturePoint(result.getString("departurePoint"));
					flight.setTotalSeatsAvailable(result.getInt("totalSeatsAvailable"));
					flight.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
					flight.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
					flight.setDepartureDate(result.getDate("departureDate").toLocalDate());
					flight.setDepartureTimings(result.getTime("departureTimings").toLocalTime());
					list.add(flight);
					return list;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		}
		throw new AirlineException("Flight is Not Found in the Airline  with the Given Flight Destination");
	}

	@Override
	public StatusBean flightBookingStatus(StatusBean bean) {

		int userId = bean.getId();

		try {
			Connection connection = link.getConnection();
			PreparedStatement getFlightPrepst = connection.prepareStatement(link.getQuery("getFlight"));

			getFlightPrepst.setInt(1, bean.getFlightId());

			try (ResultSet getResult = getFlightPrepst.executeQuery();) {
				while (getResult.next()) {
					int bookFlightId = getResult.getInt("flightId");

					if (bean.getFlightId() == bookFlightId) {

						try {
							Connection con = link.getConnection();
							PreparedStatement getUserPrepst = con.prepareStatement(link.getQuery("getUser"));
							getUserPrepst.setInt(1, bean.getId());
							try (ResultSet getUser = getUserPrepst.executeQuery();) {
								while (getUser.next()) {
									int user = getUser.getInt("id");

									if (userId == user) {

										try {
											Connection conn1 = link.getConnection();
											PreparedStatement getRequestPstmt = conn1
													.prepareStatement(link.getQuery("requestBooked"));
											getRequestPstmt.setInt(2, bean.getBookingId());
											getRequestPstmt.setInt(1, bean.getId());
											getRequestPstmt.setInt(3, bean.getFlightId());
											getRequestPstmt.setInt(4, bean.getTotalSeatsBooked());

											getRequestPstmt.executeUpdate();
											return bean;

										} catch (Exception e) {
											e.printStackTrace();
											throw new AirlineException(" Requesting  flight not Possible");
										}

									}
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
							throw new AirlineException(e.getMessage());
						}
					}
				}
			}
		} catch (AirlineException e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		}
		return null;
	}

	@Override
	public boolean cancelFlightTicket(int flightBookingId) {
		try (Connection connection = link.getConnection();
				PreparedStatement prepst = connection.prepareStatement(link.getQuery("cancelFlightTicket"));) {
			prepst.setInt(1, flightBookingId);
			int result = prepst.executeUpdate();
			if (result != 0) {
				return true;
			}

		} catch (Exception e) {
			throw new AirlineException(e.getMessage());

		}
		throw new AirlineException("Flight Ticket Was Cancelled");

	}

	@Override
	public List<StatusBean> getFlightTicketInfo(int userId) {
		List<StatusBean> tickets = new ArrayList<StatusBean>();
		try (Connection connection = link.getConnection();
				PreparedStatement prepst = connection.prepareStatement(link.getQuery("ticketInfo"));) {
			prepst.setInt(1, userId);
			ResultSet result = prepst.executeQuery();
			while (result.next()) {
				StatusBean status = new StatusBean();
				status.setBookingId(result.getInt("bookingId"));
				status.setId(result.getInt("id"));
				status.setFlightId(result.getInt("flightId"));
				status.setTotalSeatsBooked(result.getInt("totalSeatsBooked"));
				tickets.add(status);
			}
			if (tickets.isEmpty()) {
				throw new AirlineException("No flight booked with this UserId");
			} else {
				return tickets;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException("No flight Booked with this UserId");
		}
	}
}