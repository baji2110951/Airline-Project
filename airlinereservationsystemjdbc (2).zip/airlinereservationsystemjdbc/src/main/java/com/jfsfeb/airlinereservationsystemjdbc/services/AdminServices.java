package com.jfsfeb.airlinereservationsystemjdbc.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.StatusBean;

public interface AdminServices {

	boolean addFlights(FlightBean flightDetails);

	boolean removeFlight(int flightId);

	List<FlightBean> searchFlightBySource(String sourcePoint);

	List<FlightBean> searchFlightByDepature(String depaturePoint);

	List<FlightBean> getFlightDetails();

	List<StatusBean> getFlightBookingStatus();

}