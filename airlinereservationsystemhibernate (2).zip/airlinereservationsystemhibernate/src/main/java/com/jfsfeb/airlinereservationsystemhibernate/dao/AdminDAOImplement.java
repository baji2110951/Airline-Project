package com.jfsfeb.airlinereservationsystemhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemhibernate.exception.AirlineException;


public class AdminDAOImplement implements AdminDAO {

	EntityManagerFactory emf = null;
	
	@Override
	public boolean addingFlights(FlightBean flight) {
		EntityManager manager = null;
		EntityTransaction trans = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();
			manager.persist(flight);
			trans.commit();
			return true;
		} catch (Exception e) {
			trans.rollback();
			throw new AirlineException("Flight Details already Exists ");
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public boolean removeingFlight(int flightId) {
		EntityManager manager = null;
		EntityTransaction trans = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();
			FlightBean flight = manager.find(FlightBean.class, flightId);
			manager.remove(flight);
			trans.commit();
			return true;
		} catch (Exception e) {
			trans.rollback();
			throw new AirlineException("Unable to Remove The Flight");
		} finally {
			manager.close();
			emf.close();
		}
	}

	

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select e from FlightBean e where e.sourcePoint=:sourcePoint";
			TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
			  query.setParameter("sourcePoint",sourcePoint);
			List<FlightBean> list = query.getResultList();
			for (int i = 0; i < list.size()-1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		}catch (Exception e) {
			e.printStackTrace();
			
		}

		return null;
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String departurePoint) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select e from FlightBean e where e.departurePoint=:departurePoint";
			TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
			  query.setParameter("departurePoint",departurePoint);
			List<FlightBean> list = query.getResultList();
			for (int i = 0; i < list.size()-1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		}catch (Exception e) {
			e.printStackTrace();
			
		}

		return null;
	}

	@Override
	public List<FlightBean> getFlightDetails() {
		EntityManager manager = null;
		emf = Persistence.createEntityManagerFactory("TestPersistence");
		manager = emf.createEntityManager();
		String jpql = "select f from FlightBean f";
		TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
		List<FlightBean> list = query.getResultList();
		manager.close();
		emf.close();
		return list;
	}

	@Override
	public List<StatusBean> getFlightBookingStatus() {
     		
		EntityManager manager = null;
		emf = Persistence.createEntityManagerFactory("TestPersistence");
		manager = emf.createEntityManager();
		String jpql = "select s from StatusBean s";
		TypedQuery<StatusBean> query = manager.createQuery(jpql, StatusBean.class);
		List<StatusBean> list = query.getResultList();
		manager.close();
		emf.close();
		return list;
	}

	}