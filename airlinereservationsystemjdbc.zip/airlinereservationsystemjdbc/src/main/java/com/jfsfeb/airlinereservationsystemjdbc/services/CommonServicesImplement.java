package com.jfsfeb.airlinereservationsystemjdbc.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystemjdbc.dao.CommonDAO;
import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemjdbc.factory.CommonFactory;
import com.jfsfeb.airlinereservationsystemjdbc.validations.Validation;

public class CommonServicesImplement implements CommonServices {

	Validation valid = new Validation();
	CommonDAO dao = CommonFactory.getCommonDAOImplementInstance();

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {
		if (valid.validateSourcePoint(sourcePoint)) {
			return dao.searchFlightBySource(sourcePoint);
		}
		return null;
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depaturePoint) {
		if (valid.validateDepaturePoint(depaturePoint)) {
			return dao.searchFlightByDepature(depaturePoint);
		}
		return null;
	}

	@Override
	public List<FlightBean> getFlightDetails() {

		return dao.getFlightDetails();
	}

	@Override
	public boolean registration(InfoBean bean) {
		if (valid.validateId(bean.getId())) {

			if (valid.validateName(bean.getName())) {

				if (valid.validateMobile(bean.getMobileNum())) {

					if (valid.validateEmail(bean.getEmail())) {

						if (valid.validatePassword(bean.getPassword())) {

							return dao.registration(bean);
						}
					}

				}
			}
		}
		return false;
	}

	@Override
	public InfoBean login(String email, String password) {
		if (valid.validateEmail(email)) {
			if (valid.validatePassword(password)) {
				return dao.login(email, password);
			}
		}

		return null;
	}

}
