package com.jfsfeb.airlinereservationsystem.validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.jfsfeb.airlinereservationsystem.exception.AirlineException;

public class Validation {

	public boolean validateId(int id) throws AirlineException {
		String idRegEx = "[0-9]{1}[0-9]{3}";
		boolean result = false;
		if (Pattern.matches(idRegEx, String.valueOf(id))) {
			result = true;
		} else {
			throw new AirlineException("Id should be Positive number and should have only 4 Digits");
		}
		return result;
	}

	public boolean validateName(String name) throws AirlineException {
		String nameRegEx = "^(?=.{4,20}$)(?![_.-])(?!.*[.]{2})[a-zA-Z._-]+(?<![_.-])";
		boolean result = false;
		Pattern pattern = Pattern.compile(nameRegEx);
		Matcher matcher = pattern.matcher(name);
		if (matcher.matches()) {
			result = true;
		} else {
			throw new AirlineException("Please Enter a Name, It should have atleast 4 characters");
		}
		return result;
	}

	public boolean validateMobile(long mobile) throws AirlineException {
		String mobileRegEx = "(0/91)?[6-9][0-9]{9}";
		boolean result = false;
		if (Pattern.matches(mobileRegEx, String.valueOf(mobile))) {
			result = true;
		} else {
			throw new AirlineException(
					"Please Enter a Valid Mobile Number, It should have only 10 Digits and must start with 6 or 7 or 8 or 9 ");
		}
		return result;
	}

	public boolean validateEmail(String email) throws AirlineException {
		String emailRegEx = "^[a-z0-9](\\.?[a-z0-9]){5,}@g(oogle)?mail\\.(com|org)";
		boolean result = false;
		Pattern pattern = Pattern.compile(emailRegEx);
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			result = true;
		} else {
			throw new AirlineException(
					"Enter proper email such that it can have numbers , alphabets and atleast 6 chartacters before @gmail.com(eg:example1@gmail.com)");
		}
		return result;
	}

	public boolean validatePassword(String password) throws AirlineException {
		String passwordRegEx = "((?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%]).{6,20})";
		boolean result = false;
		if (Pattern.matches(passwordRegEx, String.valueOf(password))) {
			result = true;
		} else {
			throw new AirlineException(
					"Password should contain atleast 6 characters ,atleast one uppercase,atleast one lowercase,atleast one number,atleast one special symbol(@#$%) ");
		}
		return result;
	}

}