package com.jfsfeb.airlinereservationsystemhibernate.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystemhibernate.dao.UserDAO;
import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemhibernate.exception.AirlineException;
import com.jfsfeb.airlinereservationsystemhibernate.factory.UserFactory;
import com.jfsfeb.airlinereservationsystemhibernate.validations.Validation;

public class UserServicesImplement implements UserServices {

	Validation valid = new Validation();
	UserDAO dao = UserFactory.getUserDAOImplementInstance();


	@Override
	public boolean cancelFlightTicket(int ticketId) {
		if (valid.validateId(ticketId)) {
			return dao.cancelFlightTicket(ticketId);
		}
		return false;
	}

	@Override
	public List<StatusBean> getFlightTicketInfo(int userId) {
		if(valid.validateId(userId)) {
			return dao.getFlightTicketInfo(userId);
			}
			return null;
	}

	
	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {

		return dao.searchFlightBySource(sourcePoint);
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depaturePoint) {

		return dao.searchFlightByDepature(depaturePoint);
	}

	@Override
	public List<FlightBean> getFlightDetails() {

		return dao.getFlightDetails();
	}

	@Override
	public StatusBean flightBookingStatus(StatusBean status) {
		if (status != null) {

			return dao.flightBookingStatus(status);
		}
		return null;
	}

	@Override
	public List<FlightBean> searchWithSourceDepature(String sourcePoint, String depaturePoint) {

		if (valid.validateSourcePoint(sourcePoint)) {
			if (valid.validateDepaturePoint(depaturePoint)) {
				return dao.searchWithSourceDepature(sourcePoint, depaturePoint);
			}
		}
		return null;

	}

}