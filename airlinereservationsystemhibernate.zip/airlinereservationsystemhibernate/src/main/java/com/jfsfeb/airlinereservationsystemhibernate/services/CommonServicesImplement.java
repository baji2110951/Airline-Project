package com.jfsfeb.airlinereservationsystemhibernate.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystemhibernate.dao.CommonDAO;
import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemhibernate.factory.CommonFactory;
import com.jfsfeb.airlinereservationsystemhibernate.validations.Validation;

public class CommonServicesImplement implements CommonServices {

	Validation valid = new Validation();
	CommonDAO dao = CommonFactory.getCommonDAOImplementInstance();


	@Override
	public List<FlightBean> getFlightDetails() {

		return dao.getFlightDetails();
	}

	@Override
	public boolean registration(InfoBean bean) {
		if (valid.validateId(bean.getId())) {

			if (valid.validateName(bean.getName())) {

				if (valid.validateMobile(bean.getMobileNum())) {

					if (valid.validateEmail(bean.getEmail())) {

						if (valid.validatePassword(bean.getPassword())) {

							return dao.registration(bean);
						}
					}

				}
			}
		}
		return false;
	}

	@Override
	public InfoBean login(String email, String password) {
		if (valid.validateEmail(email)) {
			if (valid.validatePassword(password)) {
				return dao.login(email, password);
			}
		}

		return null;
	}

	@Override
	public List<FlightBean> searchWithSourceDepature(String sourcePoint, String depaturePoint) {

		if (valid.validateSourcePoint(sourcePoint)) {
			if (valid.validateDepaturePoint(depaturePoint)) {
				return dao.searchWithSourceDepature(sourcePoint, depaturePoint);
			}
		}
		return null;

	}
}
