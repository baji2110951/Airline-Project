
package com.jfsfeb.airlinereservationsystemhibernate.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemhibernate.exception.AirlineException;
import com.jfsfeb.airlinereservationsystemhibernate.factory.CommonFactory;
import com.jfsfeb.airlinereservationsystemhibernate.services.CommonServices;

import lombok.extern.log4j.Log4j;

@Log4j
public class Controller {
	public static void controls() {

		String validateName = null;
		long validateMobile = 0;
		String validateEmail = null;
		String validatePassword = null;
		String role = null;
		String email = null;
		String password = null;

		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		CommonServices service = CommonFactory.getCommonServicesImplementInstance();
		do {
			try {

				log.info("          --------Welcome To Airline Reservation System---------              ");

				log.info("1. View All Flights");
				log.info("2.Search Flight By SourcePoint And DeparturePoint");
				log.info("3.Already Registered ! Login Here");
				log.info("4.New User");

				int a = scan.nextInt();
				switch (a) {
				case 1:
					try {
						List<FlightBean> values = service.getFlightDetails();
						log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s", "FlightId",
								"FlightName", "SourcePoint", "DestinationPoint", "totalSeatAvailable", "ArrivalDate",
								"ArraivalTime", "DepartureDate", "DepartureTime"));
						for (FlightBean flightBean : values) {
							if (flightBean != null) {
								log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s", flightBean.getFlightId(),
										flightBean.getFlightName(), flightBean.getSourcePoint(),
										flightBean.getDeparturePoint(), flightBean.getTotalSeatsAvailable(),
										flightBean.getArrivalDate(), flightBean.getArrivalTimings(),
										flightBean.getDepartureDate(), flightBean.getDepartureTimings()));
								log.info("............................................");
							} else {
								log.info("No Flight are found with th Flight Details");
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					break;
				case 2:

					try {
						log.info("Enter flight SourcePoint : ");
						String source = scan.next();
						log.info("Search flight by Destination : ");
						String depature = scan.next();
						FlightBean bean = new FlightBean();
						bean.setSourcePoint(source);
						bean.setDeparturePoint(depature);
						List<FlightBean> flightSourceToDestination = service.searchWithSourceDepature(source, depature);
						log.info(String.format("%-10s %-10s %-13s %-15s %-20s %-20s %s", "FlightId", "FlightName",
								"Source", "Destination", "TotalSeatsAvailable", "ArraivalTime", "DepartureTime"));
						for (FlightBean flight : flightSourceToDestination) {
							if (flight != null) {
								log.info(String.format("%-10s %-10s %-13s %-15s %-20s %-20s %s", flight.getFlightId(),
										flight.getFlightName(), flight.getSourcePoint(), flight.getDeparturePoint(),
										flight.getTotalSeatsAvailable(), flight.getArrivalTimings(),
										flight.getDepartureTimings()));
							} else {
								log.info("No Flights are available with this Destination");
							}
						}
					} catch (Exception e) {
						log.error(e.getMessage());
					}
					break;

				case 3:
					log.info("Enter registered email to login : ");
					email = scan.next();
					log.info("Enter registered Password to login : ");
					password = scan.next();

					try {
						log.info("Enter your Role");
						role = scan.next();
						InfoBean bean1 = new InfoBean();
						bean1.setRole(role);
						InfoBean infoBean = service.login(email, password);
						if (infoBean != null) {
							String adminRole = "admin";
							String userRole = "user";
							if (infoBean.getRole().equals(adminRole)) {
								AdminController.adminControls();
							} else if (infoBean.getRole().equals(userRole)) {
								UserController.userControls();
							}
						} else {
							log.info("null values not allowed ");
						}
					} catch (AirlineException e) {
						e.printStackTrace();
						log.info(e.getMessage());
					}
					break;

				case 4:
					try {
			
						log.info("Enter Name to Register : ");
						validateName = scan.next();
						log.info("Enter MobileNumber to Register : ");
						validateMobile = scan.nextLong();
						log.info("Enter Email to Register : ");
						validateEmail = scan.next();
						log.info("Enter Password :");
						validatePassword = scan.next();
					
						role = "user";
						int userId = (int) (Math.random() * 10000);
						if (userId <= 1000) {
							userId = userId + 1000;
						}
				
						InfoBean bean = new InfoBean();
						bean.setId(userId);
						bean.setName(validateName);
						bean.setMobileNum(validateMobile);
						bean.setEmail(validateEmail);
						bean.setPassword(validatePassword);
						bean.setRole(role);

						boolean check = service.registration(bean);
						if (check) {
							log.info("You have registered Successfully");
						} else {
							log.info("Already registered");
						}
						break;
					} catch (InputMismatchException e) {
						log.error("Invalid entry ");
						scan.next();
						break;
					} catch (AirlineException e) {
						log.info(e.getMessage());
						break;
					}

				default:
					log.info("Invalid Choice");
					log.error("Choice must be 1 or 2 or 3 or 4");
					break;
				}
			} catch (InputMismatchException e) { 
				log.error("Invalid entry please provide 1 or 2 or 3 or 4");
				scan.nextLine();
			} catch (AirlineException e) {
				log.info(e.getMessage());

			} catch (Exception e) {
				e.printStackTrace();
				log.error("Invalid Credentials");
			}

		} while (true);
	}
}

//		do {
//			try {
//
//				log.info(".................");
//				log.info("1. Admin Block");
//				log.info("2. User Block");
//				log.info("................");
//				int a = scan.nextInt();
//				switch (a) {
//				case 1:
//					AdminServices admin = AdminFact.getAdminServicesImplementInstance();
//					do {
//						try {
//							log.info("1. Admin Register");
//							log.info("2. Admin Login");
//							log.info("3. Exit ");
//							log.info(".....................");
//							int value = scan.nextInt();
//							switch (value) {
//
//							case 1:
//
//								try {
//									log.info("Enter Admin ID: ");
//									validateId = scan.nextInt();
//
//								} catch (InputMismatchException e) {
//
//									scan.next();
//								}
//
//								log.info("Enter Name to Register : ");
//								validateName = scan.next();
//
//								try {
//									log.info("Enter MobileNumber to Register : ");
//									validateMobile = scan.nextLong();
//
//								} catch (InputMismatchException e) {
//
//									scan.next();
//								}
//
//								log.info("Enter Email to Register : ");
//								validateEmail = scan.next();
//
//								log.info("Enter Password :");
//								validatePassword = scan.next();
//
//								log.info("Enter Your Role");
//								validateRole = scan.next();
//
//								InfoBean bean = new InfoBean();
//								bean.setId(validateId);
//								bean.setName(validateName);
//								bean.setMobileNum(validateMobile);
//								bean.setEmail(validateEmail);
//								bean.setPassword(validatePassword);
//								bean.setRole(validateRole);
//								try {
//
//									boolean result = admin.adminRegistration(bean);
//									if (result) {
//										log.info("You have registered Successfully");
//									} else {
//										log.info("Already registered");
//									}
//								} catch (AirlineException e) {
//									log.error(e.getMessage());
//								}
//								break;
//
//							case 2:
//								log.info("Enter registered email to login : ");
//								String email = scan.next();
//								log.info("Enter registered Password to login : ");
//								String password = scan.next();
//								try {
//
//									@SuppressWarnings("unused")
//									InfoBean bean1 = admin.adminLogin(email, password);
//									log.info("You have successfully logged in");
//									log.info("Now you can perform the following operations:");
//									do {
//										try {
//											log.info("1.  Add Flight");
//											log.info("2. Search Flight By Source");
//											log.info("3. Search Flight by Destination");
//											log.info("4. Remove Flight");
//											log.info("5. View All Flight Details");
//											log.info("6.Flight Booking Request Status");
//											log.info("7.LogOut");
//											log.info("....................................");
//											int result1 = scan.nextInt();
//											switch (result1) {
//											case 1:
//
//												try {
//													log.info("Enter valid FlightID to add : ");
//													flightId = scan.nextInt();
//
//												} catch (InputMismatchException e) {
//
//													scan.nextInt();
//												}
//
//												log.info("Enter FlightName : ");
//												flightName = scan.next();
//
//												log.info("Enter Source point : ");
//												flightSource = scan.next();
//
//												log.info("Enter Depature Point : ");
//												flightDepature = scan.next();
//
//												try {
//													log.info("Enter Total number of seats Available in the Flight : ");
//													totalSeatsAvailable = scan.nextInt();
//
//												} catch (InputMismatchException e) {
//													scan.nextInt();
//												}
//
//												log.info(" Enter Arrival Date");
//												try {
//													arrivalDate = LocalDate.of(scan.nextInt(), scan.nextInt(),
//															scan.nextInt());
//
//												} catch (InputMismatchException e) {
//
//													log.error("its should have only digits");
//													scan.next();
//												}
//
//												log.info("Enter  Flight Arrival  Time : ");
//
//												try {
//													arrivalTimings = LocalTime.of(scan.nextInt(), scan.nextInt(),
//															scan.nextInt());
//
//												} catch (InputMismatchException e) {
//
//													log.error("its should have only digits");
//													scan.next();
//												}
//
//												log.info("Enter Departure Date : ");
//												try {
//													departureDate = LocalDate.of(scan.nextInt(), scan.nextInt(),
//															scan.nextInt());
//
//												} catch (InputMismatchException e) {
//
//													log.error("its should have only digits");
//													scan.next();
//												}
//
//												log.info("Enter  Flight departure Date Time : ");
//
//												try {
//													departureTimings = LocalTime.of(scan.nextInt(), scan.nextInt(),
//															scan.nextInt());
//
//												} catch (InputMismatchException e) {
//
//													log.error("its should contains only digits ");
//													scan.next();
//												}
//												FlightBean bean3 = new FlightBean();
//												bean3.setFlightId(flightId);
//												bean3.setFlightName(flightName);
//												bean3.setSourcePoint(flightSource);
//												bean3.setDeparturePoint(flightDepature);
//												bean3.setTotalSeatsAvailable(totalSeatsAvailable);
//												bean3.setArrivalDate(arrivalDate);
//												bean3.setArrivalTimings(arrivalTimings);
//												bean3.setDepartureDate(departureDate);
//												bean3.setDepartureTimings(departureTimings);
//												try {
//													boolean result2 = admin.addFlights(bean3);
//													if (result2) {
//														log.info("Flight with Id=" + flightId + "is added");
//													} else {
//														System.out.println(
//																"Flight with id = " + flightId + "already exists");
//													}
//												} catch (Exception ex) {
//													log.error(ex.getMessage());
//												}
//												break;
//
//											case 2:
//												log.info("Enter Source Point: ");
//												try {
//
//													String sourcePoint = scan.next();
//													FlightBean bean4 = new FlightBean();
//													bean4.setSourcePoint(sourcePoint);
//													List<FlightBean> flight = admin.searchFlightBySource(sourcePoint);
//													log.info(String.format("%-10s %-10s %-13s %-15s %-20s %-20s %s",
//															"FlightId", "FlightName", "SourcePoint", "DeparturePoint",
//															"totalSeatAvailable", "ArrivalDate", "ArraivalTime",
//															"DepartureDate", "DepartureTime"));
//													for (FlightBean flightBean : flight) {
//														if (flightBean == null) {
//															log.info("flight not available");
//
//														} else {
//
//															System.out.println(String.format(
//																	"%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
//																	flightBean.getFlightId(),
//																	flightBean.getFlightName(),
//																	flightBean.getSourcePoint(),
//																	flightBean.getDeparturePoint(),
//																	flightBean.getTotalSeatsAvailable(),
//																	flightBean.getArrivalDate(),
//																	flightBean.getArrivalTimings(),
//																	flightBean.getDepartureDate(),
//																	flightBean.getDepartureTimings()));
//
//														}
//													}
//												} catch (AirlineException e) {
//													e.printStackTrace();
//													log.error(e.getMessage());
//												}
//
//												break;
//											case 3:
//												log.info("Enter Depature Point: ");
//												try {
//
//													String depaturePoint = scan.next();
//													FlightBean bean4 = new FlightBean();
//													bean4.setSourcePoint(depaturePoint);
//													List<FlightBean> flight = admin
//															.searchFlightByDepature(depaturePoint);
//													log.info(String.format(
//															"%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
//															"FlightId", "FlightName", "SourcePoint", "DepaturePoint",
//															"totalSeatAvailable", "ArrivalDate", "ArraivalTime",
//															"DepartureDate", "DepatureTime"));
//													for (FlightBean flightBean : flight) {
//														if (flightBean == null) {
//															log.info("flight not available");
//
//														} else {
//
//															System.out.println(String.format(
//																	"%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
//																	flightBean.getFlightId(),
//																	flightBean.getFlightName(),
//																	flightBean.getSourcePoint(),
//																	flightBean.getDeparturePoint(),
//																	flightBean.getTotalSeatsAvailable(),
//																	flightBean.getArrivalDate(),
//																	flightBean.getArrivalTimings(),
//																	flightBean.getDepartureDate(),
//																	flightBean.getDepartureTimings()));
//														}
//													}
//												} catch (AirlineException e) {
//													e.printStackTrace();
//													log.error(e.getMessage());
//												}
//
//												break;
//
//											case 4:
//												log.info("Please Enter  FlightId To Be REMOVED: ");
//												int flightId1 = scan.nextInt();
//												if (flightId1 == 0) {
//													log.info("Please Enter Correct FlightID");
//												} else {
//													FlightBean bean6 = new FlightBean();
//													bean6.setFlightId(flightId1);
//													boolean remove = admin.removeFlight(flightId1);
//													if (remove) {
//														System.out
//																.println("The Flight is removed of Id = " + flightId1);
//													} else {
//														log.info("The Flight is not removed of Id = " + flightId1);
//													}
//												}
//												break;
//											case 5:
//												List<FlightBean> values = admin.getFlightDetails();
//
//												log.info(String.format(
//														"%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
//														"FlightId", "FlightName", "SourcePoint", "DestinationPoint",
//														"totalSeatAvailable", "ArrivalDate", "ArraivalTime",
//														"DepartureDate", "DepartureTime"));
//												for (FlightBean flightBean : values) {
//													if (flightBean != null) {
//														log.info(String.format("%-10s %-10s %-13s %-15s  %s",
//																flightBean.getFlightId(), flightBean.getFlightName(),
//																flightBean.getSourcePoint(),
//																flightBean.getDeparturePoint(),
//																flightBean.getTotalSeatsAvailable(),
//																flightBean.getArrivalDate(),
//																flightBean.getArrivalTimings(),
//																flightBean.getDepartureDate(),
//																flightBean.getDepartureTimings()));
//														log.info("............................................");
//													} else {
//														log.info("No Flight are found with th Flight Details");
//													}
//												}
//												break;
//											case 6:
//												List<StatusBean> bookingStatus = admin.getFlightBookingStatus();
//
//												log.info(String.format(
//														"%-10s %-10s %-10s %-10s %-13s %-15s %-20s %-20s %s",
//														"FlightId", "FlightName", "UserID", "UserName", "Source",
//														"Departure", "TotalSeatsBooked"));
//												for (StatusBean req : bookingStatus) {
//													if (req != null) {
//														log.info(String.format(
//																"%-10s %-10s %-10s %-10s %-13s %-15s %-20s %-20s %s",
//																req.getFlightBeans().getFlightId(),
//																req.getFlightBeans().getFlightName(),
//																req.getUserBeans().getId(),
//																req.getUserBeans().getName(),
//																req.getFlightBeans().getSourcePoint(),
//																req.getFlightBeans().getDeparturePoint(),
//
//																req.getTotalSeatsBooked()));
//													} else {
//														log.info("No Request found in booking status");
//													}
//												}
//												break;
//											case 7:
//												controls();
//
//											default:
//												log.error(
//														"Invalid entry please provide  integer 1 or 2 or 3 or 4 or 5 or 6");
//												break;
//											}
//										} catch (InputMismatchException e) {
//											log.error("Please Enter a Positive value greater than 0");
//											scan.nextLine();
//										}
//									} while (true);
//								} catch (Exception e) {
//									e.printStackTrace();
//									log.info("Invalid Credentials");
//								}
//								break;
//							case 3:
//								controls();
//
//							default:
//								log.error("Entered value should be 1 or 2 or 3");
//								break;
//							}
//						} catch (InputMismatchException e) {
//							log.error("Please enter only a positive integer");
//							scan.nextLine();
//						}
//					} while (true);
//				case 2:
//					UserServices user = UserFact.getUserServicesImplementInstance();
//					do {
//						try {
//							log.info("1. User Registration");
//							log.info("2. User Login");
//							log.info("3. Exit");
//							log.info("....................................................................");
//							int value = scan.nextInt();
//							switch (value) {
//							case 1:
//
//								try {
//									log.info("Enter user ID ");
//									validateId = scan.nextInt();
//
//								} catch (InputMismatchException e) {
//
//									scan.next();
//								}
//
//								log.info("Enter Name to Register : ");
//								validateName = scan.next();
//
//								try {
//									log.info("Enter MobileNumber to Register : ");
//									validateMobile = scan.nextLong();
//
//								} catch (InputMismatchException e) {
//
//									scan.next();
//								}
//
//								log.info("Enter Email to Register : ");
//								validateEmail = scan.next();
//
//								log.info("Enter Password :");
//								validatePassword = scan.next();
//
//								log.info("enter your role :");
//								validateRole = scan.next();
//
//								InfoBean bean1 = new InfoBean();
//								bean1.setId(validateId);
//								bean1.setName(validateName);
//								bean1.setMobileNum(validateMobile);
//								bean1.setEmail(validateEmail);
//								bean1.setPassword(validatePassword);
//								bean1.setRole(validateRole);
//								try {
//									boolean check = user.userRegistration(bean1);
//									if (check) {
//										log.info("Registered Successfully");
//									} else {
//										log.info("Already registered");
//									}
//								} catch (Exception e) {
//									log.error(e.getMessage());
//								}
//								break;
//
//							case 2:
//								log.info("Enter registered email to login : ");
//								String email = scan.next();
//								log.info("Enter registered Password to login : ");
//								String password = scan.next();
//								try {
//									@SuppressWarnings("unused")
//									InfoBean beans3 = user.userLogin(email, password);
//									log.info("Logged in Successfully");
//									do {
//										try {
//											log.info("1. Search Flight By Source");
//											log.info("2.Search Flifht By Depature Point");
//											log.info("3.View Flight Details");
//											log.info("4.Search By SourcePoint and DeparturePoint");
//											log.info("5.Request for Flight Booking");
//											log.info("6.Logout");
//											int result3 = scan.nextInt();
//											switch (result3) {
//											case 1:
//												log.info("Enter Source Point: ");
//												try {
//
//													String sourcePoint = scan.next();
//													FlightBean bean4 = new FlightBean();
//													bean4.setSourcePoint(sourcePoint);
//													List<FlightBean> flight = user.searchFlightBySource(sourcePoint);
//													log.info(String.format(
//															"%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
//															"FlightId", "FlightName", "SourcePoint", "DepaturePoint",
//															"totalSeatAvailable", "ArrivalDate", "ArraivalTime",
//															"DepartureDate", "DepartureTime"));
//													for (FlightBean flightBean : flight) {
//														if (flightBean == null) {
//															log.info("flight not available");
//
//														} else {
//
//															System.out.println(String.format(
//																	"%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
//																	flightBean.getFlightId(),
//																	flightBean.getFlightName(),
//																	flightBean.getSourcePoint(),
//																	flightBean.getDeparturePoint(),
//																	flightBean.getTotalSeatsAvailable(),
//																	flightBean.getArrivalDate(),
//																	flightBean.getArrivalTimings(),
//																	flightBean.getDepartureDate(),
//																	flightBean.getDepartureTimings()));
//
//														}
//													}
//												} catch (AirlineException e) {
//													e.printStackTrace();
//													log.error(e.getMessage());
//												}
//
//												break;
//											case 2:
//												log.info("Enter Depature Point: ");
//												try {
//
//													String depaturePoint = scan.next();
//													FlightBean bean4 = new FlightBean();
//													bean4.setSourcePoint(depaturePoint);
//													List<FlightBean> flight = user
//															.searchFlightByDepature(depaturePoint);
//													log.info(String.format(
//															"%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
//															"FlightId", "FlightName", "SourcePoint", "DepaturePoint",
//															"totalSeatAvailable", "ArrivalDate", "ArraivalTime",
//															"DepartureDate", "DepartureTime"));
//													for (FlightBean flightBean : flight) {
//														if (flightBean == null) {
//															log.info("flight not available");
//
//														} else {
//
//															System.out.println(String.format(
//																	"%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
//																	flightBean.getFlightId(),
//																	flightBean.getFlightName(),
//																	flightBean.getSourcePoint(),
//																	flightBean.getDeparturePoint(),
//																	flightBean.getTotalSeatsAvailable(),
//																	flightBean.getArrivalDate(),
//																	flightBean.getArrivalTimings(),
//																	flightBean.getDepartureDate(),
//																	flightBean.getDepartureTimings()));
//														}
//													}
//												} catch (AirlineException e) {
//													log.error(e.getMessage());
//												}
//
//												break;
//											case 3:
//												try {
//													List<FlightBean> values = user.getFlightDetails();
//
//													log.info(String.format(
//															"%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s ",
//															"FlightId", "FlightName", "SourcePoint", "DestinationPoint",
//															"totalSeatAvailable", "ArrivalDate", "ArraivalTime",
//															"DepartureDate", "DepartureTime"));
//													for (FlightBean flightBean : values) {
//														if (flightBean != null) {
//															log.info(String.format(
//																	"%-10s %-10s %-13s %-15s  %-20s %-20s %s",
//																	flightBean.getFlightId(),
//																	flightBean.getFlightName(),
//																	flightBean.getSourcePoint(),
//																	flightBean.getDeparturePoint(),
//																	flightBean.getTotalSeatsAvailable(),
//																	flightBean.getArrivalTimings(),
//																	flightBean.getDepartureTimings()));
//														}
//													}
//
//												} catch (Exception e) {
//													log.error(e.getMessage());
//												}
//												break;
//											case 4:
//												try {
//													log.info("Enter flight SourcePoint : ");
//													String source = scan.next();
//													log.info("Search flight by Destination : ");
//													String depature = scan.next();
//													FlightBean bean = new FlightBean();
//													bean.setSourcePoint(source);
//													bean.setDeparturePoint(depature);
//													List<FlightBean> flightSourceToDestination = user
//															.searchWithSourceDepature(source, depature);
//													log.info(String.format("%-10s %-10s %-13s %-15s %-20s %-20s %s",
//															"FlightId", "FlightName", "Source", "Destination",
//															"TotalSeatsAvailable", "ArraivalTime", "DepartureTime"));
//													for (FlightBean flight : flightSourceToDestination) {
//														if (flight != null) {
//															log.info(String.format(
//																	"%-10s %-10s %-13s %-15s %-20s %-20s %s",
//																	flight.getFlightId(), flight.getFlightName(),
//																	flight.getSourcePoint(), flight.getDeparturePoint(),
//																	flight.getTotalSeatsAvailable(),
//																	flight.getArrivalTimings(),
//																	flight.getDepartureTimings()));
//														} else {
//															log.info("No Flights are available with this Destination");
//														}
//													}
//												} catch (Exception e) {
//													log.error(e.getMessage());
//												}
//												break;
//											case 5:
//												log.info("Enter Source Point: ");
//												String source1 = scan.next();
//												log.info("Enter Depature Point : ");
//												String depature1 = scan.next();
//												FlightBean bean2 = new FlightBean();
//												bean2.setSourcePoint(source1);
//												bean2.setDeparturePoint(depature1);
//												List<FlightBean> flightSourceToDestination1 = user
//														.searchWithSourceDepature(source1, depature1);
//
//												log.info(String.format("%-10s %-10s %-13s %-15s  %-20s %-20s %s",
//														"FlightId", "FlightName", "Source", "Destination",
//														"TotalSeatAvailable", "ArraivalTime", "DepartureTime"));
//												for (FlightBean flight : flightSourceToDestination1) {
//													if (flight != null) {
//														log.info(String.format(
//																"%-10s %-10s %-13s %-15s  %-20s %-20s %s",
//																flight.getFlightId(), flight.getFlightName(),
//																flight.getSourcePoint(), flight.getDeparturePoint(),
//																flight.getTotalSeatsAvailable(),
//																flight.getArrivalTimings(),
//																flight.getDepartureTimings()));
//													} else {
//														log.info("No Flights are available with this Destination");
//													}
//												}
//												do {
//													try {
//
//														log.info("1.  Book Ticket");
//														log.info("2. Logout from account ");
//														
//														int check = scan.nextInt();
//														switch (check) {
//														case 1:
//															try {
//																log.info("Enter User Id : ");
//																int id = scan.nextInt();
//																InfoBean userBean = new InfoBean();
//																userBean.setId(id);
//																log.info("Enter Flight Id : ");
//																int flightId1 = scan.nextInt();
//																FlightBean flightBean = new FlightBean();
//																flightBean.setFlightId(flightId1);
//																log.info("Enter No of seats to be Booked: ");
//																int totalSeats = scan.nextInt();
//																int passId = (int) (Math.random() * 10000);
//																if (passId <= 1000) {
//																	passId = passId + 1000;
//																}
//																
//																StatusBean status = new StatusBean();
//																status.setTotalSeatsBooked(totalSeats);
//															    status.setPassId(passId);
//																status.setId(id);
//															    status.setFlightId(flightId1);
//																try {
//																	StatusBean req = user.flightBookingStatus(status);
//																	log.info("Request placed to Airline Management ");
//																	log.info(
//																			"<--------------------------------------------------------------------->");
//																	log.info(String.format("%-10s %-10s %-10s %s","TicketId",
//																			"FlightId", "UserID", "NoofSeatBooked"));
//																	;
//																	log.info(String.format("%-10s %-10s %-10s %s",
//																			req.getPassId(),
//																			req.getFlightId(),
//																			req.getId(),
//																			req.getTotalSeatsBooked()));
//																} catch (Exception e) {
//																	log.info("Invalid Request for flight booking");
//																}
//															} catch (InputMismatchException e) {
//																log.error("Invalid entry  ");
//																scan.nextLine();
//															} catch (Exception e) {
//																e.printStackTrace();
//																log.info("Invalid request");
//															}
//															break;
//														case 2:
//															controls();
//														default:
//															log.error("Invalid entry please provide 1 or 2 ");
//															break;
//														}
//													} catch (InputMismatchException e) {
//														log.error("Invalid entry please provide 1 or 2 ");
//														scan.nextLine();
//													} catch (AirlineException e) {
//														log.info(e.getMessage());
//													}
//												} while (true);
//
////														int check = scan.nextInt();
////														switch (check) {
////														case 1:
////															try {
////																log.info("Enter User Id : ");
////																int id = scan.nextInt();
////																InfoBean userBean = new InfoBean();
////																userBean.setId(id);
////																log.info("Enter Flight Id : ");
////																int flightId1 = scan.nextInt();
////																FlightBean flightBean = new FlightBean();
////																flightBean.setFlightId(flightId1);
////																log.info("Enter No of seats to be Booked: ");
////																int totalSeats = scan.nextInt();
////																StatusBean bookingStatus = new StatusBean();
////																bookingStatus.setTotalSeatsBooked(totalSeats);
////																try {
////																	StatusBean req = user.flightBookingStatus(bean)
////																	log.info("Request placed");
////																	log.info(String.format(
////																			"%-10s %-10s %-10s %-10s %-13s %-15s %-20s %-20s %s",
////																			"FlightId", "FlightName", "UserID",
////																			"UserName", "Source", "Destination",
////																			"TotalSeatsBooked", "ArraivalTime",
////																			"DepatureTime"));
////																	log.info(String.format(
////																			"%-10s %-10s %-10s %-10s %-13s %-15s  %s",
////																			req.getFlightBeans().getFlightId(),
////																			req.getFlightBeans().getFlightName(),
////																			req.getUserBeans().getId(),
////																			req.getUserBeans().getName(),
////																			req.getFlightBeans().getSourcePoint(),
////																			req.getFlightBeans().getDeparturePoint(),
////																			req.getFlightBeans().getArrivalTimings(),
////																			req.getFlightBeans().getDepartureTimings(),
////																			bookingStatus.getTotalSeatsBooked()));
////																} catch (Exception e) {
////																	log.info("Invalid Request of booking");
////																}
////															} catch (InputMismatchException e) {
////																log.error("Invalid entry  ");
////																scan.nextLine();
////															} catch (Exception e) {
////																log.info("Invalid request");
////															}
////															break;
////														case 2:
////															controls();
////														default:
////															log.error("Invalid entry please provide 1 or 2 ");
////															break;
////														}
////													} catch (InputMismatchException e) {
////														log.error("Invalid entry please provide 1 or 2 ");
////														scan.nextLine();
////													} catch (AirlineException e) {
////														log.info(e.getMessage());
////													}
////												} while (true);
//
//											case 6:
//												controls();
//
//											default:
//												break;
//											}
//										} catch (InputMismatchException e) {
//											log.error("Invalid entry please provide only positive integer");
//											scan.nextLine();
//										}
//									} while (true);
//								} catch (Exception e) {
//									log.error("Invalid Credentials");
//								}
//								break;
//							case 3:
//								controls();
//								break;
//
//							default:
//								log.info("Invalid Choice");
//								log.error("Choice must be 1 or 2");
//								break;
//							}
// } catch (InputMismatchException e) {
//							log.error("Invalid  please enter provide only positive integer");
//							scan.nextLine();
//						}
//					} while (true);
//
//				default:
//					log.error("Invalid choice ,Enter 1 Or 2");
//					break;
//				}
//
//			} catch (InputMismatchException e) {
//				log.error("Please enter only positive integer 1 or 2");
//				scan.nextLine();
//			}
// } while (true);
// }

//}