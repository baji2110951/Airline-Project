package com.jfsfeb.airlinereservationsystem.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;


@Data
@SuppressWarnings("serial")
public class AdminBean implements Serializable {

	private int adminId;
	private String adminName;
	private String email;
	@ToString.Exclude
	private String adminPass;
	private long adminMobileNum;

}