package com.jfsfeb.airlinereservationsystem.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystem.dao.UserDAO;
import com.jfsfeb.airlinereservationsystem.dao.UserDAOImplement;
import com.jfsfeb.airlinereservationsystem.dto.FlightBean;
import com.jfsfeb.airlinereservationsystem.dto.UserBean;
import com.jfsfeb.airlinereservationsystem.validations.Validation;

public class UserServicesImplement implements UserServices {

	Validation valid = new Validation();
	UserDAO dao = new UserDAOImplement();

	@Override
	public boolean userRegistration(UserBean bean) {

		return dao.userRegistration(bean);
	}

	@Override
	public UserBean userLogin(String emailId, String userPass) {

		if (valid.validateEmail(emailId)) {
			if (valid.validatePassword(userPass)) {

				return dao.userLogin(emailId, userPass);
			}
		}
		return null;
	}

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {

		return dao.searchFlightBySource(sourcePoint);
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depaturePoint) {

		return dao.searchFlightByDepature(depaturePoint);
	}

	@Override
	public List<FlightBean> getFlightDetails() {

		return dao.getFlightDetails();
	}

}