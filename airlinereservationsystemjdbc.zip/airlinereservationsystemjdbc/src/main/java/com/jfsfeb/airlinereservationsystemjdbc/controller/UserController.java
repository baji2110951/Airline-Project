package com.jfsfeb.airlinereservationsystemjdbc.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemjdbc.exception.AirlineException;
import com.jfsfeb.airlinereservationsystemjdbc.factory.UserFact;
import com.jfsfeb.airlinereservationsystemjdbc.services.UserServices;

import lombok.extern.log4j.Log4j;

@Log4j
public class UserController {
	public static void userControls() {

		UserServices user = UserFact.getUserServicesImplementInstance();
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);

		do {
			try {
				log.info("1. Search Flight By Source");
				log.info("2.Search Flifht By Depature Point");
				log.info("3.View Flight Details");
				log.info("4.Search By SourcePoint and DeparturePoint");
				log.info("5.Request for Flight Booking");
				log.info("5.Cancel The FlightTicket");
				log.info("7.Get Flight Ticket Details");
				log.info("8.Logout");
				int result = scan.nextInt();
				switch (result) {
				case 1:
					log.info("Enter Source Point: ");
					try {

						String sourcePoint = scan.next();
						FlightBean bean4 = new FlightBean();
						bean4.setSourcePoint(sourcePoint);
						List<FlightBean> flight = user.searchFlightBySource(sourcePoint);
						log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s", "FlightId",
								"FlightName", "SourcePoint", "DepaturePoint", "totalSeatAvailable", "ArrivalDate",
								"ArraivalTime", "DepartureDate", "DepartureTime"));
						for (FlightBean flightBean : flight) {
							if (flightBean == null) {
								log.info("flight not available");

							} else {

								System.out.println(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
										flightBean.getFlightId(), flightBean.getFlightName(),
										flightBean.getSourcePoint(), flightBean.getDeparturePoint(),
										flightBean.getTotalSeatsAvailable(), flightBean.getArrivalDate(),
										flightBean.getArrivalTimings(), flightBean.getDepartureDate(),
										flightBean.getDepartureTimings()));

							}
						}
					} catch (AirlineException e) {
						e.printStackTrace();
						log.error(e.getMessage());
					}

					break;
				case 2:
					log.info("Enter Depature Point: ");
					try {

						String depaturePoint = scan.next();
						FlightBean bean4 = new FlightBean();
						bean4.setSourcePoint(depaturePoint);
						List<FlightBean> flight = user.searchFlightByDepature(depaturePoint);
						log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s", "FlightId",
								"FlightName", "SourcePoint", "DepaturePoint", "totalSeatAvailable", "ArrivalDate",
								"ArraivalTime", "DepartureDate", "DepartureTime"));
						for (FlightBean flightBean : flight) {
							if (flightBean == null) {
								log.info("flight not available");

							} else {

								System.out.println(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
										flightBean.getFlightId(), flightBean.getFlightName(),
										flightBean.getSourcePoint(), flightBean.getDeparturePoint(),
										flightBean.getTotalSeatsAvailable(), flightBean.getArrivalDate(),
										flightBean.getArrivalTimings(), flightBean.getDepartureDate(),
										flightBean.getDepartureTimings()));
							}
						}
					} catch (AirlineException e) {
						log.error(e.getMessage());
					}

					break;
				case 3:
					try {
						List<FlightBean> values = user.getFlightDetails();

						log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s ", "FlightId",
								"FlightName", "SourcePoint", "DestinationPoint", "totalSeatAvailable", "ArrivalDate",
								"ArraivalTime", "DepartureDate", "DepartureTime"));
						for (FlightBean flightBean : values) {
							if (flightBean != null) {
								log.info(String.format("%-10s %-10s %-13s %-15s  %-20s %-20s %s",
										flightBean.getFlightId(), flightBean.getFlightName(),
										flightBean.getSourcePoint(), flightBean.getDeparturePoint(),
										flightBean.getTotalSeatsAvailable(), flightBean.getArrivalTimings(),
										flightBean.getDepartureTimings()));
							}
						}

					} catch (Exception e) {
						log.error(e.getMessage());
					}
					break;
				case 4:
					try {
						log.info("Enter flight SourcePoint : ");
						String source = scan.next();
						log.info("Search flight by Destination : ");
						String depature = scan.next();
						FlightBean bean = new FlightBean();
						bean.setSourcePoint(source);
						bean.setDeparturePoint(depature);
						List<FlightBean> flightSourceToDestination = user.searchWithSourceDepature(source, depature);
						log.info(String.format("%-10s %-10s %-13s %-15s %-20s %-20s %s", "FlightId", "FlightName",
								"Source", "Destination", "TotalSeatsAvailable", "ArraivalTime", "DepartureTime"));
						for (FlightBean flight : flightSourceToDestination) {
							if (flight != null) {
								log.info(String.format("%-10s %-10s %-13s %-15s %-20s %-20s %s", flight.getFlightId(),
										flight.getFlightName(), flight.getSourcePoint(), flight.getDeparturePoint(),
										flight.getTotalSeatsAvailable(), flight.getArrivalTimings(),
										flight.getDepartureTimings()));
							} else {
								log.info("No Flights are available with this Destination");
							}
						}
					} catch (Exception e) {
						log.error(e.getMessage());
					}
					break;
				case 5:
					log.info("Enter Source Point: ");
					String source1 = scan.next();
					log.info("Enter Depature Point : ");
					String depature1 = scan.next();
					FlightBean bean2 = new FlightBean();
					bean2.setSourcePoint(source1);
					bean2.setDeparturePoint(depature1);
					List<FlightBean> flightSourceToDestination1 = user.searchWithSourceDepature(source1, depature1);

					log.info(String.format("%-10s %-10s %-13s %-15s  %-20s %-20s %s", "FlightId", "FlightName",
							"Source", "Destination", "TotalSeatAvailable", "ArraivalTime", "DepartureTime"));
					for (FlightBean flight : flightSourceToDestination1) {
						if (flight != null) {
							log.info(String.format("%-10s %-10s %-13s %-15s  %-20s %-20s %s", flight.getFlightId(),
									flight.getFlightName(), flight.getSourcePoint(), flight.getDeparturePoint(),
									flight.getTotalSeatsAvailable(), flight.getArrivalTimings(),
									flight.getDepartureTimings()));
						} else {
							log.info("No Flights are available with this Destination");
						}
					}
					do {
						try {

							log.info("1.  Book Ticket");
							log.info("2. Logout from account ");

							int check = scan.nextInt();
							switch (check) {
							case 1:
								try {
									log.info("Enter User Id : ");
									int id = scan.nextInt();
									InfoBean userBean = new InfoBean();
									userBean.setId(id);
									log.info("Enter Flight Id : ");
									int flightId1 = scan.nextInt();
									FlightBean flightBean = new FlightBean();
									flightBean.setFlightId(flightId1);
									log.info("Enter No of seats to be Booked: ");
									int totalSeats = scan.nextInt();
									int bookingId = (int) (Math.random() * 10000);
									if (bookingId <= 1000) {
										bookingId = bookingId + 1000;
									}

									StatusBean status = new StatusBean();
									status.setTotalSeatsBooked(totalSeats);
									status.setBookingId(bookingId);
									status.setId(id);
									status.setFlightId(flightId1);
									try {
										StatusBean req = user.flightBookingStatus(status);
										log.info("Request placed to Airline Management ");
										log.info(
												"<--------------------------------------------------------------------->");
										log.info(String.format("%-10s %-10s %-10s %s", "TicketId", "FlightId", "UserID",
												"NoofSeatBooked"));
										;
										log.info(String.format("%-10s %-10s %-10s %s", req.getBookingId(),
												req.getFlightId(), req.getId(), req.getTotalSeatsBooked()));
									} catch (Exception e) {
										log.info("Invalid Request for flight booking");
									}
								} catch (InputMismatchException e) {
									log.error("Invalid entry  ");
									scan.nextLine();
								} catch (Exception e) {
									e.printStackTrace();
									log.info("Invalid request");
								}
								break;
							case 2:
								Controller.controls();
							default:
								log.error("Invalid entry please provide 1 or 2 ");
								break;
							}
						} catch (InputMismatchException e) {
							log.error("Invalid entry please provide 1 or 2 ");
							scan.nextLine();
						} catch (AirlineException e) {
							log.info(e.getMessage());
						}
					} while (true);

				
				case 6:
					log.info("Cancel Flight Ticket  ");
					log.info("Enter Flight BookingId");
					try {
						int ticketId = scan.nextInt();
						user.cancelFlightTicket(ticketId);
						if (ticketId == 0) {
							log.info("Please Enter the Valid FlightId");
						} else {
							StatusBean book = new StatusBean();
							book.setBookingId(ticketId);
							boolean remove = user.cancelFlightTicket(ticketId);
							if (remove) {
								log.info("The Cancel ticket Id = " + ticketId);
							} else {
								log.info("The Ticked Id is not removed = " + ticketId);
							}
						}
					} catch (InputMismatchException e) {
						log.error("Invalid entry valid Id");
						scan.nextLine();
					} catch (AirlineException e) {
						log.info(e.getMessage());
					}
					break;
				case 7:
					log.info("Please Enter UserId to get FlightBooking Details");
					try {
						int userId = scan.nextInt();
						List<StatusBean> ticket = user.getFlightTicketInfo(userId);

						log.info("<--------------------------------------------------------------------->");
						log.info(String.format("%-10s %-10s %-10s %s", "TicketID", "FlightId", "UserID",
								"NoofSeatBooked"));
						for (StatusBean request : ticket) {
							if (request != null) {
								log.info(String.format("%-10s %-10s %-10s %s", request.getBookingId(),
										request.getFlightId(), request.getId(), request.getTotalSeatsBooked()));
							} else {
								log.info("Request not found in booking status");
							}
						}
					} catch (InputMismatchException e) {
						log.error("Invalid entry valid Id");
						scan.nextLine();
					} catch (AirlineException e) {
						log.info(e.getMessage());
					}
					break;

				case 8:
					Controller.controls();

				default:
					break;
				}
			} catch (InputMismatchException e) {
				log.error("Invalid entry please provide only positive integer");
				scan.next();
			}
		} while (true);
	}
}
