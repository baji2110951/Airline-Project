package com.jfsfeb.airlinereservationsystemjdbc.dto;

import java.io.Serializable;

import lombok.Data;
@SuppressWarnings("serial")
@Data
public class StatusBean implements Serializable{

	private FlightBean flightBeans;
	private InfoBean userBeans;
	private int id;
	private int flightId;
	private int bookingId;
	private int totalSeatsBooked;
}
