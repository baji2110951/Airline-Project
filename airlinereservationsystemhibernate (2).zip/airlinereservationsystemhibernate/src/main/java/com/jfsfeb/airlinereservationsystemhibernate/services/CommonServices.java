package com.jfsfeb.airlinereservationsystemhibernate.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;

public interface CommonServices {

	List<FlightBean> searchWithSourceDepature(String sourcePoint, String depaturePoint);

	List<FlightBean> getFlightDetails();

	boolean registration(InfoBean bean);

	InfoBean login(String email, String password);
}
