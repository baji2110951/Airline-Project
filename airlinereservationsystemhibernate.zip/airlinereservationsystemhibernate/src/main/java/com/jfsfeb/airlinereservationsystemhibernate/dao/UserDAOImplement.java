package com.jfsfeb.airlinereservationsystemhibernate.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemhibernate.exception.AirlineException;

public class UserDAOImplement implements UserDAO {

	EntityManagerFactory emf = null;

	@Override
	public boolean cancelFlightTicket(int ticketId) {
		EntityManager manager = null;
		EntityTransaction trans = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			trans = manager.getTransaction();
			trans.begin();
			StatusBean bookingStatus = manager.find(StatusBean.class, ticketId);
			manager.remove(bookingStatus);
			trans.commit();
			return true;
		} catch (Exception e) {
			trans.rollback();
			throw new AirlineException("Ticket with this Id can't be Deleted");
		} finally {
			manager.close();
			emf.close();
		}
	}

	@Override
	public List<StatusBean> getFlightTicketInfo(int userId) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select s from StatusBean s where s.id=:id";
			TypedQuery<StatusBean> query = manager.createQuery(jpql, StatusBean.class);
			query.setParameter("id", userId);
			List<StatusBean> list = query.getResultList();
			for (int i = 0; i < list.size() - 1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select s from FlightBean s where s.sourcePoint=:sourcePoint";
			TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
			query.setParameter("sourcePoint", sourcePoint);
			List<FlightBean> list = query.getResultList();
			for (int i = 0; i < list.size() - 1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();

		}

		return null;
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String departurePoint) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select f from FlightBean f where f.departurePoint=:departurePoint";
			TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
			query.setParameter("departurePoint", departurePoint);
			List<FlightBean> list = query.getResultList();
			for (int i = 0; i < list.size() - 1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();

		}

		return null;
	}

	@Override
	public List<FlightBean> getFlightDetails() {
		EntityManager manager = null;
		emf = Persistence.createEntityManagerFactory("TestPersistence");
		manager = emf.createEntityManager();
		String jpql = "select f from FlightBean f";
		TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
		List<FlightBean> list = query.getResultList();
		manager.close();
		emf.close();
		return list;
	}

	@Override
	public List<FlightBean> searchWithSourceDepature(String sourcePoint, String departurePoint) {
		EntityManager manager = null;
		try {
			emf = Persistence.createEntityManagerFactory("TestPersistence");
			manager = emf.createEntityManager();
			String jpql = "Select d from FlightBean d where d.sourcePoint=:sourcePoint and d.departurePoint=:departurePoint";
			TypedQuery<FlightBean> query = manager.createQuery(jpql, FlightBean.class);
			query.setParameter("sourcePoint", sourcePoint);
			query.setParameter("departurePoint", departurePoint);
			List<FlightBean> list = query.getResultList();
			for (int i = 0; i < list.size() - 1; i++) {
				list.get(i);
			}
			manager.close();
			emf.close();
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public StatusBean flightBookingStatus(StatusBean status) {

		return null;
	}

}