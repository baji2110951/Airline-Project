package com.jfsfeb.airlinereservationsystemjdbc.dao;

import java.util.List;

import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.StatusBean;

public interface UserDAO {

	boolean cancelFlightTicket(int flightbookingId);
	
    List<StatusBean> getFlightTicketInfo(int userId);

	List<FlightBean> searchFlightBySource(String sourcePoint);

	List<FlightBean> searchFlightByDepature(String depaturePoint);

	List<FlightBean> getFlightDetails();

	StatusBean flightBookingStatus(StatusBean bean);
	
	List<FlightBean> searchWithSourceDepature(String sourcePoint,String depaturePoint);

}