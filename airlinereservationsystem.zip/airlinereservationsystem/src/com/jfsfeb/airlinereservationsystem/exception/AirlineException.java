package com.jfsfeb.airlinereservationsystem.exception;

@SuppressWarnings("serial")
public class AirlineException extends RuntimeException {
	public AirlineException(String msg) {
		super(msg);
	}
}
