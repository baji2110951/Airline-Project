package com.jfsfeb.airlinereservationsystemhibernate.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.airlinereservationsystemhibernate.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemhibernate.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemhibernate.exception.AirlineException;
import com.jfsfeb.airlinereservationsystemhibernate.factory.AdminFactory;
import com.jfsfeb.airlinereservationsystemhibernate.factory.CommonFactory;
import com.jfsfeb.airlinereservationsystemhibernate.services.AdminServices;
import com.jfsfeb.airlinereservationsystemhibernate.services.CommonServices;

import lombok.extern.log4j.Log4j;

@Log4j
public class AdminController {

	public static void adminControls() {

		int flightId = 0;
		String flightName = null;
		String flightSource = null;
		String flightDepature = null;
		int totalSeatsAvailable = 0;
		LocalDate arrivalDate = null;
		LocalTime arrivalTimings = null;
		LocalDate departureDate = null;
		LocalTime departureTimings = null;

		String validateName = null;
		long validateMobile = 0;
		String validateEmail = null;
		String validatePassword = null;
		String role = null;

		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		AdminServices admin = AdminFactory.getAdminServicesImplementInstance();
		CommonServices service = CommonFactory.getCommonServicesImplementInstance();

		log.info("...............................................");
		log.info("You have successfully logged in");
		log.info("Now you can perform the following operations:");
		log.info("..................................................");
		do {
			try {
				log.info("1.  Add Flight");
				log.info("2. Search Flight By Source");
				log.info("3. Search Flight by Destination");
				log.info("4. Remove Flight");
				log.info("5. View All Flight Details");
				log.info("6.Flight Booking Request Status");
				log.info("7.Add New Admin");
				log.info("8.LogOut");
				log.info("....................................");
				int result1 = scan.nextInt();
				switch (result1) {
				case 1:
					log.info("                     ADDING A FLIGHT                       ");
					try {
						log.info("Enter  FlightId   : ");
						flightId = scan.nextInt();

					} catch (InputMismatchException e) {

						scan.nextInt();
					}

					log.info("Enter FlightName : ");
					flightName = scan.next();

					log.info("Enter Source point : ");
					flightSource = scan.next();

					log.info("Enter Depature Point : ");
					flightDepature = scan.next();

					try {
						log.info("Enter Total number of seats Available in the Flight : ");
						totalSeatsAvailable = scan.nextInt();

					} catch (InputMismatchException e) {
						scan.nextInt();
					}

					log.info(" Enter Arrival Date in this Format [YYYY-MM-DD] : ");
					try {
						arrivalDate = LocalDate.of(scan.nextInt(), scan.nextInt(), scan.nextInt());

					} catch (InputMismatchException e) {

						log.error("its should have only digits");
						scan.next();
					}

					log.info("Enter  Flight Arrival  Time in this Format [HH-MIN-SECS] : ");

					try {
						arrivalTimings = LocalTime.of(scan.nextInt(), scan.nextInt(), scan.nextInt());

					} catch (InputMismatchException e) {

						log.error("its should have only digits");
						scan.next();
					}

					log.info("Enter Departure Date  in this Format [YYYY-MM-DD] : ");
					try {
						departureDate = LocalDate.of(scan.nextInt(), scan.nextInt(), scan.nextInt());

					} catch (InputMismatchException e) {

						log.error("its should have only digits");
						scan.next();
					}

					log.info("Enter  Flight departure Date Time in this Format [HH-MIN-SECS] : ");

					try {
						departureTimings = LocalTime.of(scan.nextInt(), scan.nextInt(), scan.nextInt());

					} catch (InputMismatchException e) {

						log.error("its should contains only digits ");
						scan.next();
					}
					FlightBean bean3 = new FlightBean();
					bean3.setFlightId(flightId);
					bean3.setFlightName(flightName);
					bean3.setSourcePoint(flightSource);
					bean3.setDeparturePoint(flightDepature);
					bean3.setTotalSeatsAvailable(totalSeatsAvailable);
					bean3.setArrivalDate(arrivalDate);
					bean3.setArrivalTimings(arrivalTimings);
					bean3.setDepartureDate(departureDate);
					bean3.setDepartureTimings(departureTimings);
					try {
						boolean result2 = admin.addFlights(bean3);
						if (result2) {
							log.info(".........................................");
							log.info("Flight with Id=" + flightId + "is added");
							log.info(".........................................");
						} else {
							System.out.println("Flight with id = " + flightId + "already exists");
						}
					} catch (Exception ex) {
						log.error(ex.getMessage());
					}
					break;

				case 2:
					log.info("                  SEARCH WITH SOURCE POINT                ");
					log.info("Enter Source Point  : ");
					try {

						String sourcePoint = scan.next();
						FlightBean bean4 = new FlightBean();
						bean4.setSourcePoint(sourcePoint);
						List<FlightBean> flight = admin.searchFlightBySource(sourcePoint);
						log.info(String.format("%-10s %-10s %-13s %-15s %-20s %-20s %s", "FlightId", "FlightName",
								"SourcePoint", "DeparturePoint", "totalSeatAvailable", "ArrivalDate", "ArraivalTime",
								"DepartureDate", "DepartureTime"));
						for (FlightBean flightBean : flight) {
							if (flightBean == null) {
								log.info("flight not available");

							} else {

								System.out.println(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
										flightBean.getFlightId(), flightBean.getFlightName(),
										flightBean.getSourcePoint(), flightBean.getDeparturePoint(),
										flightBean.getTotalSeatsAvailable(), flightBean.getArrivalDate(),
										flightBean.getArrivalTimings(), flightBean.getDepartureDate(),
										flightBean.getDepartureTimings()));

							}
						}
					} catch (AirlineException e) {
						e.printStackTrace();
						log.error(e.getMessage());
					}

					break;
				case 3:
					log.info("                    SEARCH WITH DEPARTURE POINT                     ");
					log.info("Enter Depature Point: ");
					try {

						String depaturePoint = scan.next();
						FlightBean bean4 = new FlightBean();
						bean4.setSourcePoint(depaturePoint);
						List<FlightBean> flight = admin.searchFlightByDepature(depaturePoint);
						log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s", "FlightId",
								"FlightName", "SourcePoint", "DepaturePoint", "totalSeatAvailable", "ArrivalDate",
								"ArraivalTime", "DepartureDate", "DepatureTime"));
						for (FlightBean flightBean : flight) {
							if (flightBean == null) {
								log.info("flight not available");

							} else {

								System.out.println(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
										flightBean.getFlightId(), flightBean.getFlightName(),
										flightBean.getSourcePoint(), flightBean.getDeparturePoint(),
										flightBean.getTotalSeatsAvailable(), flightBean.getArrivalDate(),
										flightBean.getArrivalTimings(), flightBean.getDepartureDate(),
										flightBean.getDepartureTimings()));
							}
						}
					} catch (AirlineException e) {
						e.printStackTrace();
						log.error(e.getMessage());
					}

					break;

				case 4:
					log.info("                 REMOVING FLIGHT                    ");
					log.info("Please Enter  FlightId To Be Removed  : ");
					int flightId1 = scan.nextInt();
					if (flightId1 == 0) {
						log.info("Please Enter Correct FlightID");
					} else {
						FlightBean bean6 = new FlightBean();
						bean6.setFlightId(flightId1);
						boolean remove = admin.removeFlight(flightId1);
						if (remove) {
							System.out.println("The Flight is removed of Id = " + flightId1);
						} else {
							log.info("The Flight is not removed of Id = " + flightId1);
						}
					}
					break;
				case 5:
					log.info("                           GET ALL FLIGHT DETAILS                    ");
					List<FlightBean> values = admin.getFlightDetails();

					log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s", "FlightId",
							"FlightName", "SourcePoint", "DestinationPoint", "totalSeatAvailable", "ArrivalDate",
							"ArraivalTime", "DepartureDate", "DepartureTime"));
					log.info("..............................................................................................................");
					for (FlightBean flightBean : values) {
						if (flightBean != null) {
							log.info(String.format("%-10s %-10s %-13s %-15s %-15s %-15s %-20s %-20s %s",
									flightBean.getFlightId(), flightBean.getFlightName(), flightBean.getSourcePoint(),
									flightBean.getDeparturePoint(), flightBean.getTotalSeatsAvailable(),
									flightBean.getArrivalDate(), flightBean.getArrivalTimings(),
									flightBean.getDepartureDate(), flightBean.getDepartureTimings()));
							log.info("............................................................................................................");
						} else {
							log.info("No Flight are found with th Flight Details");
						}
					}
					break;
				case 6:
					List<StatusBean> bookingStatus = admin.getFlightBookingStatus();

					log.info("                      SEE BOOKING STATUS                     ");
					log.info("...............................................................................");
					log.info(
							String.format("%-10s %-10s %-10s %s", "BookingID", "FlightId", "UserID", "NoofSeatBooked"));
					for (StatusBean response : bookingStatus) {
						if (response != null) {
							log.info("..........................................................................");
							log.info(String.format("%-10s %-10s %-10s %s", response.getBookingId(),
									response.getFlightId(), response.getId(), response.getTotalSeatsBooked()));
						} else {
							log.info("Request not found in booking status");
						}
					}
					break;

				case 7:
					try {

						log.info("                   ADDING NEW ADMIN                           ");
						log.info("Enter Name to Register : ");
						validateName = scan.next();
						log.info("Enter MobileNumber to Register : ");
						validateMobile = scan.nextLong();
						log.info("Enter Email to Register : ");
						validateEmail = scan.next();
						log.info("Enter Password :");
						validatePassword = scan.next();
						log.info("Enter Role as admin or user :");
						role = scan.next();
						int userId = (int) (Math.random() * 10000);
						if (userId <= 1000) {
							userId = userId + 1000;
						}
						InfoBean bean = new InfoBean();
						bean.setId(userId);
						bean.setName(validateName);
						bean.setMobileNum(validateMobile);
						bean.setEmail(validateEmail);
						bean.setPassword(validatePassword);
						bean.setRole(role);

						boolean check = service.registration(bean);
						if (check) {
							log.info("You have registered Successfully");
						} else {
							log.info("Already registered");
						}
						break;
					} catch (InputMismatchException e) {
						log.error("Invalid entry ");
						scan.next();
						break;
					} catch (AirlineException e) {
						log.info(e.getMessage());
						break;
					}
				case 8:
					Controller.controls();

				default:
					log.error("Invalid entry please provide  integer 1 or 2 or 3 or 4 or 5 or 6 or 7 or 8");
					break;
				}
			} catch (InputMismatchException e) {
				log.error("Please Enter a Positive value greater than 0");
				scan.nextLine();
			} catch (Exception e) {
				e.printStackTrace();
				log.info("Invalid Credentials");
			}
		} while (true);
	}

}
