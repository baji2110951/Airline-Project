package com.jfsfeb.airlinereservationsystemhibernate.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.ToString;

@Data
@Entity
@Table(name="info_bean")
@SuppressWarnings("serial")
public class InfoBean implements Serializable {

	@Id
	@Column
	private int id;
	@Column
	private String name;
	@Column
	private String email;
	@Column
	@ToString.Exclude
	private String password;
	@Column(name="mobilenum")
	private long mobileNum;
	@Column
	private String role;
}
