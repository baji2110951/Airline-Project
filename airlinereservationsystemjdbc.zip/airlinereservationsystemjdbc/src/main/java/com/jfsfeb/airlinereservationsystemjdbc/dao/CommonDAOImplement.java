package com.jfsfeb.airlinereservationsystemjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.InfoBean;
import com.jfsfeb.airlinereservationsystemjdbc.exception.AirlineException;
import com.jfsfeb.airlinereservationsystemjdbc.utility.Utility;

public class CommonDAOImplement implements CommonDAO {

	Utility link = new Utility();
	
	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {
		FlightBean flight = null;
		List<FlightBean> list = new ArrayList<FlightBean>();
		try (Connection connection = link.getConnection();
				PreparedStatement prepst = connection.prepareStatement(link.getQuery("flightBySource"));) {
			prepst.setString(1, sourcePoint);
			try (ResultSet result = prepst.executeQuery();) {
				if (result.next()) {
					flight = new FlightBean();
					flight.setFlightId(result.getInt("flightId"));
					flight.setFlightName(result.getString("flightName"));
					flight.setSourcePoint(result.getString("sourcePoint"));
					flight.setDeparturePoint(result.getString("departurePoint"));
					flight.setTotalSeatsAvailable(result.getInt("TotalSeatsAvailable"));
					flight.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
					flight.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
					flight.setDepartureDate(result.getDate("departureDate").toLocalDate());
					flight.setDepartureTimings(result.getTime("departureTimings").toLocalTime());
					list.add(flight);
					return list;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		}
		throw new AirlineException("Flight is Not Found in the Airline  with the Given Flight Source");
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depaturePoint) {
		FlightBean flight = null;
		List<FlightBean> list = new ArrayList<FlightBean>();
		try {
		Connection connection = link.getConnection();
				PreparedStatement prepst = connection.prepareStatement(link.getQuery("flightByDeparture"));
			prepst.setString(1, depaturePoint);
			try (ResultSet result = prepst.executeQuery();) {
				if (result.next()) {
					flight = new FlightBean();
					flight.setFlightId(result.getInt("flightId"));
					flight.setFlightName(result.getString("flightName"));
					flight.setSourcePoint(result.getString("sourcePoint"));
					flight.setDeparturePoint(result.getString("departurePoint"));
					flight.setTotalSeatsAvailable(result.getInt("totalSeatsAvailable"));
					flight.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
					flight.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
					flight.setDepartureDate(result.getDate("departureDate").toLocalDate());
					flight.setDepartureTimings(result.getTime("departureTimings").toLocalTime());
					list.add(flight);
					return list;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		}
		throw new AirlineException("Flight Not Present with this DeparturePoint");

	}

	@Override
	public List<FlightBean> getFlightDetails() {
		List<FlightBean> list = new LinkedList<FlightBean>();
		try (Connection connection = link.getConnection();
				Statement st = connection.createStatement();
				ResultSet result = st.executeQuery(link.getQuery("allFlights"))) {
			while (result.next()) {
				FlightBean info = new FlightBean();
				info.setFlightId(result.getInt("flightId"));
				info.setFlightName(result.getString("flightName"));
				info.setSourcePoint(result.getString("sourcePoint"));
				info.setDeparturePoint(result.getString("departurePoint"));
				info.setTotalSeatsAvailable(result.getInt("totalSeatsAvailable"));
				info.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
				info.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
				info.setDepartureDate(result.getDate("departureDate").toLocalDate());
				info.setDepartureTimings(result.getTime("departureTimings").toLocalTime());
			
				list.add(info);
			}
			if (list.isEmpty()) {
				throw new AirlineException("Flights were not Present");
			} else {
				return list;
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		}
		
	}

	@Override
	public boolean registration(InfoBean bean) {
		try {
			Connection connection = link.getConnection();
			PreparedStatement prepst = connection.prepareStatement(link.getQuery("addingUser"));

			prepst.setInt(1, bean.getId());
			prepst.setString(2, bean.getName());
			prepst.setLong(3, bean.getMobileNum());
			prepst.setString(4, bean.getEmail());
			prepst.setString(5, bean.getPassword());
			prepst.setString(6, bean.getRole());

			prepst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException("Already Registered ! Unable to Add Admin ");
		}
		return true;
	}

	@Override
	public InfoBean login(String email, String password) {
		InfoBean data = new InfoBean();

		try {
			Connection conn = link.getConnection();
			PreparedStatement prepst = conn.prepareStatement(link.getQuery("adminLogin"));
			prepst.setString(1, email);
			prepst.setString(2, password);
			
			try {
				ResultSet result = prepst.executeQuery();
				while (result.next()) {
					data.setEmail(result.getString("email"));
					data.setPassword(result.getString("password"));
					data.setRole(result.getString("role"));
				}
				return data;

			} catch (Exception e) {
				e.printStackTrace();
				throw new AirlineException("Invalid Data, Please Enter Correctly");

			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException("Invalid Data, Please Enter Correctly");

		}
		
		
	}

}