package com.jfsfeb.airlinereservationsystem.dao;

import java.util.List;

import com.jfsfeb.airlinereservationsystem.dto.AdminBean;
import com.jfsfeb.airlinereservationsystem.dto.FlightBean;

public interface AdminDAO {
	boolean adminRegistration(AdminBean bean);

	AdminBean adminLogin(String email, String adminPass);

	boolean addFlights(FlightBean flightDetails);

	boolean removeFlight(int flightId);

	List<FlightBean> searchFlightBySource(String sourcePoint);

	List<FlightBean> searchFlightByDepature(String depaturePoint);

	List<FlightBean> getFlightDetails();
}
