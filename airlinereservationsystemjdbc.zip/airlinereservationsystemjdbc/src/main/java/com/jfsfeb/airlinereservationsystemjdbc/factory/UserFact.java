package com.jfsfeb.airlinereservationsystemjdbc.factory;

import com.jfsfeb.airlinereservationsystemjdbc.dao.*;
import com.jfsfeb.airlinereservationsystemjdbc.services.*;

public class UserFact {

	private UserFact() {
	}

	public static UserDAO getUserDAOImplementInstance() {
		UserDAO daoUser = new UserDAOImplement();
		return daoUser;
	}

	public static UserServices getUserServicesImplementInstance() {
		UserServices serviceUser = new UserServicesImplement();
		return serviceUser;
	}
}