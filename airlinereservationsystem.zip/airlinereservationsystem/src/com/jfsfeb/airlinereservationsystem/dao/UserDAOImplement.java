package com.jfsfeb.airlinereservationsystem.dao;

import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.airlinereservationsystem.dto.FlightBean;
import com.jfsfeb.airlinereservationsystem.dto.UserBean;
import com.jfsfeb.airlinereservationsystem.exception.AirlineException;
import com.jfsfeb.airlinereservationsystem.repository.AirlineDB;

public class UserDAOImplement implements UserDAO {

	@Override
	public boolean userRegistration(UserBean bean) {

		for (UserBean u1 : AirlineDB.userD) {
			if ((u1.getUserEmail()).equals(bean.getUserEmail())) {
				return false;
			}
		}
		AirlineDB.userD.add(bean);
		return true;
	}

	@Override
	public UserBean userLogin(String emailId, String userPass) {

		for (UserBean u2 : AirlineDB.userD) {
			if ((u2.getUserEmail().equals(emailId)) && (u2.getUserPass().equals(userPass))) {
				return u2;
			}
		}
		throw new AirlineException("Invalid Credentials");
	}

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {

		List<FlightBean> list = new ArrayList<FlightBean>();
		for (int i = 0; i <= AirlineDB.flightD.size() - 1; i++) {
			FlightBean flight = AirlineDB.flightD.get(i);
			String source = flight.getSourcePoint();
			if (sourcePoint.equals(source)) {
				list.add(flight);
			}
		}
		if (list.size() == 0) {
			throw new AirlineException("Flight not found");
		} else {
			return list;
		}
	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depaturePoint) {

		ArrayList<FlightBean> searchData = new ArrayList<FlightBean>();
		for (int i = 0; i <= AirlineDB.flightD.size() - 1; i++) {
			FlightBean flight = AirlineDB.flightD.get(i);
			String destination = flight.getDepaturePoint();
			if (depaturePoint.equals(destination)) {
				searchData.add(flight);
			}
		}
		if (searchData.size() == 0) {
			throw new AirlineException("Flight not found");
		} else {
			return searchData;
		}
	}

	@Override
	public List<FlightBean> getFlightDetails() {

		return AirlineDB.flightD;
	}

}
