
package com.jfsfebi.airlinereservationsystem.controller;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.jfsfeb.airlinereservationsystem.dto.*;
import com.jfsfeb.airlinereservationsystem.exception.AirlineException;
import com.jfsfeb.airlinereservationsystem.repository.AirlineDB;
import com.jfsfeb.airlinereservationsystem.services.*;
import com.jfsfeb.airlinereservationsystem.validations.Validation;
@log4j
public class Controller {
	public static void controls() {

		AirlineDB.addDataToDB();

		boolean flag = false;
		int validateId = 0;
		String validateName = null;
		long validateMobile = 0;
		String validateEmail = null;
		String validatePassword = null;

		int flightId = 0;
		String flightName = null;
		String flightSource = null;
		String flightDepature = null;
		int totalSeatsAvailable = 0;

		Validation valid = new Validation();

		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		do {
			try {
				System.out.println("          --------Welcome To Airline Reservation System---------              ");
				System.out.println(".................");
				System.out.println("1. Admin Block");
				System.out.println("2. User Block");
				System.out.println("................");
				int a = s.nextInt();
				switch (a) {
				case 1:
					AdminServices admin = new AdminServicesImplement();
					do {
						try {
							System.out.println("1. Admin Register");
							System.out.println("2. Admin Login");
							System.out.println("3. Exit ");
							System.out.println(".....................");
							int value = s.nextInt();
							switch (value) {

							case 1:
								do {
									try {
										System.out.println("Enter Admin ID: ");
										validateId = s.nextInt();
										valid.validateId(validateId);
										flag = true;
									} catch (InputMismatchException e) {
										System.err.println("ID should have only digits");
										flag = false;
										s.next();
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);
								do {
									try {
										System.out.println("Enter Name to Register : ");
										validateName = s.next();
										valid.validateName(validateName);
										flag = true;
									} catch (InputMismatchException e) {
										flag = false;
										System.err.println("Name should have only Alphabates");
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);
								do {
									try {
										System.out.println("Enter MobileNumber to Register : ");
										validateMobile = s.nextLong();
										valid.validateMobile(validateMobile);
										flag = true;
									} catch (InputMismatchException e) {
										System.err.println("Mobile Number should have only numbers");
										flag = false;
										s.next();
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);
								do {
									try {
										System.out.println("Enter Email to Register : ");
										validateEmail = s.next();
										valid.validateEmail(validateEmail);
										flag = true;
									} catch (InputMismatchException e) {
										flag = false;
										System.err.println(
												"Enter Email in such way that it should have numbers and alphabets and @gmail.com");
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);
								do {
									try {
										System.out.println("Enter Password :");
										validatePassword = s.next();
										valid.validatePassword(validatePassword);
										flag = true;
									} catch (InputMismatchException e) {
										flag = false;
										System.err.println("Password will not take spaces as characters ");
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);

								AdminBean bean = new AdminBean();
								bean.setAdminId(validateId);
								bean.setAdminName(validateName);
								bean.setAdminMobileNum(validateMobile);
								bean.setEmail(validateEmail);
								bean.setAdminPass(validatePassword);

								boolean result = admin.adminRegistration(bean);
								if (result) {
									System.out.println("You have registered Successfully");
								} else {
									System.out.println("Already registered");
								}
								break;

							case 2:
								System.out.println("Enter registered email to login : ");
								String email = s.next();
								System.out.println("Enter registered Password to login : ");
								String password = s.next();
								try {

									@SuppressWarnings("unused")
									AdminBean bean1 = admin.adminLogin(email, password);
									System.out.println("You have successfully logged in");
									System.out.println("Now you can perform the following operations:");
									do {
										try {
											System.out.println("1.  Add Flight");
											System.out.println("2. Search Flight By Source");
											System.out.println("3. Search Flight by Destination");
											System.out.println("4. Remove Flight");
											System.out.println("5. View All Flight Details");
											System.out.println("6.Exit");
											System.out.println("....................................");
											int result1 = s.nextInt();
											switch (result1) {
											case 1:

												do {
													System.out.println("Enter valid FlightID to add : ");
													flightId = s.nextInt();
													try {
														valid.validateId(flightId);
														flag = true;
													} catch (InputMismatchException e) {
														flag = false;
														System.err.println(
																"Id should have only digits no alphabates and symbols are alloed");
													} catch (AirlineException e) {
														flag = false;
														System.err.println(e.getMessage());
													}
												} while (!flag);
												do {
													System.out.println("Enter FlightName : ");
													flightName = s.next();
													try {
														valid.validateName(flightName);
														flag = true;
													} catch (InputMismatchException e) {
														flag = false;
														System.err.println(
																"FlightName should have only Alphabets no numbers or symbols are alowed");
													} catch (AirlineException e) {
														flag = false;
														System.err.println(e.getMessage());
													}
												} while (!flag);
												do {
													System.out.println("Enter Source point : ");
													flightSource = s.next();
													try {
														valid.validateName(flightSource);
														flag = true;
													} catch (InputMismatchException e) {
														flag = false;
														System.err.println("It should have only Alphabates");
													} catch (AirlineException e) {
														flag = false;
														System.err.println(e.getMessage());
													}
												} while (!flag);
												do {
													System.out.println("Enter Depature Point : ");
													flightDepature = s.next();
													try {
														valid.validateName(flightDepature);
														flag = true;
													} catch (InputMismatchException e) {
														flag = false;
														System.err.println(
																"Destination should have only Alphabates no digits are alowed");
													} catch (AirlineException e) {
														flag = false;
														System.err.println(e.getMessage());
													}
												} while (!flag);
												do {
													System.out.println(
															"Enter Total number of seats Available in the Flight : ");

													try {
														totalSeatsAvailable = s.nextInt();
														flag = true;
													} catch (InputMismatchException e) {
														flag = false;
														System.err.println(
																"totalSeatsAvailable should contains only digits");
													} catch (AirlineException e) {
														flag = false;
														System.err.println(e.getMessage());
													}
												} while (!flag);
												FlightBean bean3 = new FlightBean();
												bean3.setFlightId(flightId);
												bean3.setFlightName(flightName);
												bean3.setSourcePoint(flightSource);
												bean3.setDepaturePoint(flightDepature);
												bean3.setTotalSeatsAvailable(totalSeatsAvailable);
												boolean result2 = admin.addFlights(bean3);
												if (result2) {
													System.out.println("Flight with Id=" + flightId + "is added");
												} else {
													System.out
															.println("Flight with id = " + flightId + "already exists");
												}
												break;
											case 2:
												System.out.println("Enter Source Point: ");
												try {

													String sourcePoint = s.next();
													FlightBean bean4 = new FlightBean();
													bean4.setSourcePoint(sourcePoint);
													List<FlightBean> flight = admin.searchFlightBySource(sourcePoint);
													System.out.println(String.format("%-10s %-10s %-13s %-15s %s",
															"FlightId", "FlightName", "SourcePoint", "DepaturePoint",
															"totalSeatAvailable"));
													for (FlightBean flightBean : flight) {
														if (flightBean == null) {
															System.out.println("flight not available");
//														
														} else {
															
															System.out
																	.println(String.format("%-10s %-10s %-13s %-15s %s",
																			flightBean.getFlightId(),
																			flightBean.getFlightName(),
																			flightBean.getSourcePoint(),
																			flightBean.getDepaturePoint(),
																			flightBean.getTotalSeatsAvailable()));
														}
													}
												} catch (AirlineException e) {
													System.err.println(e.getMessage());
												}

												break;
											case 3:
												System.out.println("Enter Depature Point: ");
												try {

													String depaturePoint = s.next();
													FlightBean bean4 = new FlightBean();
													bean4.setSourcePoint(depaturePoint);
													List<FlightBean> flight = admin
															.searchFlightByDepature(depaturePoint);
													System.out.println(String.format("%-10s %-10s %-13s %-15s %s",
															"FlightId", "FlightName", "SourcePoint", "DepaturePoint",
															"totalSeatAvailable"));
													for (FlightBean flightBean : flight) {
														if (flightBean == null) {
															System.out.println("flight not available");

														} else {

															System.out
																	.println(String.format("%-10s %-10s %-13s %-15s %s",
																			flightBean.getFlightId(),
																			flightBean.getFlightName(),
																			flightBean.getSourcePoint(),
																			flightBean.getDepaturePoint(),
																			flightBean.getTotalSeatsAvailable()));
														}
													}
												} catch (AirlineException e) {
													System.err.println(e.getMessage());
												}

												break;

											case 4:
												System.out.println("Please Enter  FlightId To Be REMOVED: ");
												int flightId1 = s.nextInt();
												if (flightId1 == 0) {
													System.out.println("Please Enter Correct FlightID");
												} else {
													FlightBean bean6 = new FlightBean();
													bean6.setFlightId(flightId1);
													boolean remove = admin.removeFlight(flightId1);
													if (remove) {
														System.out
																.println("The Flight is removed of Id = " + flightId1);
													} else {
														System.out.println(
																"The Flight is not removed of Id = " + flightId1);
													}
												}
												break;
											case 5:
												List<FlightBean> values = admin.getFlightDetails();

												System.out.println(String.format("%-10s %-10s %-13s %-15s %s",
														"FlightId", "FlightName", "SourcePoint", "DestinationPoint",
														"totalSeatAvailable"));
												for (FlightBean flightBean : values) {
													if (flightBean != null) {
														System.out.println(String.format("%-10s %-10s %-13s %-15s  %s",
																flightBean.getFlightId(), flightBean.getFlightName(),
																flightBean.getSourcePoint(),
																flightBean.getDepaturePoint(),
																flightBean.getTotalSeatsAvailable()));
														System.out.println("............................................");
													} else {
														System.out.println(
																"No Flight are available in the Flight Details");
													}
												}
												break;
											case 6:
												controls();

											default:
												System.err.println(
														"Invalid entry please provide  integer 1 or 2 or 3 or 4 or 5 or 6");
												break;
											}
										} catch (InputMismatchException e) {
											System.err.println("Please Enter a Positive value greater than 0");
											s.nextLine();
										}
									} while (true);
								} catch (Exception e) {
									System.out.println("Invalid Credentials");
								}
								break;
							case 3:
								controls();
								// break;
							default:
								System.err.println("Entered value should be 1 or 2 or 3");
								break;
							}
						} catch (InputMismatchException e) {
							System.err.println("Please enter only a positive integer");
							s.nextLine();
						}
					} while (true);
				case 2:
					UserServices user = new UserServicesImplement();
					do {
						try {
							System.out.println("1. User Registration");
							System.out.println("2. User Login");
							System.out.println("3. Exit");
							System.out.println("....................................................................");
							int value = s.nextInt();
							switch (value) {
							case 1:

								do {
									try {
										System.out.println("Enter user ID ");
										validateId = s.nextInt();
										valid.validateId(validateId);
										flag = true;
									} catch (InputMismatchException e) {
										System.err.println("ID should consist of only digits");
										flag = false;
										s.next();
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);
								do {
									try {
										System.out.println("Enter Name to Register : ");
										validateName = s.next();
										valid.validateName(validateName);
										flag = true;
									} catch (InputMismatchException e) {
										flag = false;
										System.err.println("Name should consists of only Alphabates");
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);
								do {
									try {
										System.out.println("Enter MobileNumber to Register : ");
										validateMobile = s.nextLong();
										valid.validateMobile(validateMobile);
										flag = true;
									} catch (InputMismatchException e) {
										System.err.println("Mobile Number  should consists of only numbers");
										flag = false;
										s.next();
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);
								do {
									try {
										System.out.println("Enter Email to Register : ");
										validateEmail = s.next();
										valid.validateEmail(validateEmail);
										flag = true;
									} catch (InputMismatchException e) {
										flag = false;
										System.err.println(
												"Enter proper email such that it should consist of numbers and alphabets");
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);
								do {
									try {
										System.out.println("Enter Password :");
										validatePassword = s.next();
										valid.validatePassword(validatePassword);
										flag = true;
									} catch (InputMismatchException e) {
										flag = false;
										System.err.println("Password will not accept spaces ");
									} catch (AirlineException e) {
										flag = false;
										System.err.println(e.getMessage());
									}
								} while (!flag);
								UserBean bean1 = new UserBean();
								bean1.setUserId(validateId);
								bean1.setUserName(validateName);
								bean1.setUserMobileNum(validateMobile);
								bean1.setUserEmail(validateEmail);
								bean1.setUserPass(validatePassword);

								boolean check = user.userRegistration(bean1);
								if (check) {
									System.out.println("Registered Successfully");
								} else {
									System.out.println("Already registered");
								}
								break;

							case 2:
								System.out.println("Enter registered email to login : ");
								String email = s.next();
								System.out.println("Enter registered Password to login : ");
								String password = s.next();
								try {
									@SuppressWarnings("unused")
									UserBean beans3 = user.userLogin(email, password);
									System.out.println("Logged in Successfully");
									do {
										try {
											System.out.println("1. Search Flight By Source");
											System.out.println("2.Search Flifht By Depature Point");
											System.out.println("3.View Flight Details");
											System.out.println("4.Logout");
											int result3 = s.nextInt();
											switch (result3) {
											case 1:
												System.out.println("Enter Source Point: ");
												try {

													String sourcePoint = s.next();
													FlightBean bean4 = new FlightBean();
													bean4.setSourcePoint(sourcePoint);
													List<FlightBean> flight = user.searchFlightBySource(sourcePoint);
													System.out.println(String.format("%-10s %-10s %-13s %-15s %s",
															"FlightId", "FlightName", "SourcePoint", "DepaturePoint",
															"totalSeatAvailable"));
													for (FlightBean flightBean : flight) {
														if (flightBean == null) {
															System.out.println("flight not available");
//														
														} else {
															
															System.out
																	.println(String.format("%-10s %-10s %-13s %-15s %s",
																			flightBean.getFlightId(),
																			flightBean.getFlightName(),
																			flightBean.getSourcePoint(),
																			flightBean.getDepaturePoint(),
																			flightBean.getTotalSeatsAvailable()));
														}
													}
												} catch (AirlineException e) {
													System.err.println(e.getMessage());
												}

												break;
											case 2:
												System.out.println("Enter Depature Point: ");
												try {

													String depaturePoint = s.next();
													FlightBean bean4 = new FlightBean();
													bean4.setSourcePoint(depaturePoint);
													List<FlightBean> flight = user
															.searchFlightByDepature(depaturePoint);
													System.out.println(String.format("%-10s %-10s %-13s %-15s %s",
															"FlightId", "FlightName", "SourcePoint", "DepaturePoint",
															"totalSeatAvailable"));
													for (FlightBean flightBean : flight) {
														if (flightBean == null) {
															System.out.println("flight not available");

														} else {

															System.out
																	.println(String.format("%-10s %-10s %-13s %-15s %s",
																			flightBean.getFlightId(),
																			flightBean.getFlightName(),
																			flightBean.getSourcePoint(),
																			flightBean.getDepaturePoint(),
																			flightBean.getTotalSeatsAvailable()));
														}
													}
												} catch (AirlineException e) {
													System.err.println(e.getMessage());
												}

												break;
											case 3:
												try {
												List<FlightBean> values = user.getFlightDetails();
                                                
												System.out.println(String.format("%-10s %-10s %-13s %-15s %s",
														"FlightId", "FlightName", "SourcePoint", "DestinationPoint",
														"totalSeatAvailable"));
												for (FlightBean flightBean : values) {
													if (flightBean != null) {
														System.out.println(String.format("%-10s %-10s %-13s %-15s  %s",
																flightBean.getFlightId(), 
																flightBean.getFlightName(),
																flightBean.getSourcePoint(),
																flightBean.getDepaturePoint(),
																flightBean.getTotalSeatsAvailable()));
													}
												}
													
												}catch(Exception e) {
													System.err.println(e.getMessage());
												}
												break;

											case 4:
												controls();
                                           
											default:
												break;
											}
										} catch (InputMismatchException e) {
											System.err.println("Invalid entry please provide only positive integer");
											s.nextLine();
										}
									} while (true);
								} catch (Exception e) {
									System.err.println("Invalid Credentials");
								}
								break;
							case 3:
								controls();
								break;

							default:
								System.out.println("Invalid Choice");
								System.err.println("Choice must be 1 or 2");
								break;
							}
						} catch (InputMismatchException e) {
							System.err.println("Invalid  please enter provide only positive integer");
							s.nextLine();
						}
					} while (true);

				default:
					System.err.println("Invalid choice ,Enter 1 Or 2");
					break;
				}

			} catch (InputMismatchException e) {
				System.err.println("Please enter only positive integer 1 or 2");
				s.nextLine();
			}
		} while (true);
	}

}