package com.jfsfeb.airlinereservationsystemjdbc.services;

import java.util.List;

import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.InfoBean;

public interface CommonServices {

	List<FlightBean> searchFlightBySource(String sourcePoint);

	List<FlightBean> searchFlightByDepature(String depaturePoint);

	List<FlightBean> getFlightDetails();
	
	boolean registration(InfoBean bean);

	InfoBean login(String email, String password);
}
