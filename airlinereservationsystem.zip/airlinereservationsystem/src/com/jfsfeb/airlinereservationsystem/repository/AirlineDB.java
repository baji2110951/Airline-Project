package com.jfsfeb.airlinereservationsystem.repository;

import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import com.jfsfeb.airlinereservationsystem.dto.AdminBean;
import com.jfsfeb.airlinereservationsystem.dto.FlightBean;
import com.jfsfeb.airlinereservationsystem.dto.UserBean;

public class AirlineDB {

	public static final List<AdminBean> adminD = new ArrayList<AdminBean>();
	public static final List<UserBean> userD = new ArrayList<UserBean>();
	public static final List<FlightBean> flightD = new ArrayList<FlightBean>();

	public static void addDataToDB() {

		AdminBean bean = new AdminBean();
		bean.setAdminId(1234);
		bean.setAdminName("abcd");
		bean.setEmail("abcdef@gmail.com");
		bean.setAdminPass("ABcD@123");
		bean.setAdminMobileNum(9877654321l);
		adminD.add(bean);

		UserBean bean1 = new UserBean();
		bean1.setUserId(1111);
		bean1.setUserName("baji");
		bean1.setUserEmail("user1234@gmail.com");
		bean1.setUserPass("User@1234");
		bean1.setUserMobileNum(9876554321l);
		userD.add(bean1);

		FlightBean flight = new FlightBean();
		flight.setFlightId(2222);
		flight.setFlightName("Air India");
		flight.setSourcePoint("Chennai");
		flight.setDepaturePoint("Bangalore");
		flight.setTotalSeatsAvailable(25);
		flight.setArrivalDateTime(LocalDateTime.of(2020, Month.MAY, 1, 20, 30));
		flight.setDepartureDateTime(LocalDateTime.of(2020, Month.MAY, 1, 22, 30));
		flightD.add(flight);

		FlightBean flight1 = new FlightBean();
		flight1.setFlightId(2002);
		flight1.setFlightName("IndiGo");
		flight1.setSourcePoint("Bhuvaneswar");
		flight1.setDepaturePoint("Hyderabad");
		flight1.setTotalSeatsAvailable(25);
		flight1.setArrivalDateTime(LocalDateTime.of(2020, Month.JUNE, 16, 5, 00));
		flight1.setDepartureDateTime(LocalDateTime.of(2020, Month.JUNE, 16, 5, 30));
		flightD.add(flight1);

		FlightBean flight2 = new FlightBean();
		flight2.setFlightId(2003);
		flight2.setFlightName("GoAir");
		flight2.setSourcePoint("Goa");
		flight2.setDepaturePoint("Hyderabad");
		flight2.setTotalSeatsAvailable(20);
		flight2.setArrivalDateTime(LocalDateTime.of(2020, Month.JANUARY, 15, 16, 10));
		flight2.setDepartureDateTime(LocalDateTime.of(2020, Month.JANUARY, 15, 17, 10));
		flightD.add(flight2);
	}

}
