package com.jfsfeb.airlinereservationsystem.dto;

import java.io.Serializable;

import lombok.Data;
import lombok.ToString;

@Data
@SuppressWarnings("serial")
public class UserBean implements Serializable {

	private int userId;
	private String userName;
	private String userEmail;
	@ToString.Exclude
	private String userPass;
	private long userMobileNum;

}
