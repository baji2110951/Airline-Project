package com.jfsfeb.airlinereservationsystemjdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.jfsfeb.airlinereservationsystemjdbc.dto.FlightBean;
import com.jfsfeb.airlinereservationsystemjdbc.dto.StatusBean;
import com.jfsfeb.airlinereservationsystemjdbc.exception.AirlineException;
import com.jfsfeb.airlinereservationsystemjdbc.utility.Utility;

public class AdminDAOImplement implements AdminDAO {

	Utility link = new Utility();

	@Override
	public boolean addFlights(FlightBean flight) {
		try {
			Connection connection = link.getConnection();
			PreparedStatement prepst = connection.prepareStatement(link.getQuery("addingFlight"));
			prepst.setInt(1, flight.getFlightId());
			prepst.setString(2, flight.getFlightName());
			prepst.setString(3, flight.getSourcePoint());
			prepst.setString(4, flight.getDeparturePoint());
			prepst.setInt(5, flight.getTotalSeatsAvailable());
			prepst.setDate(6, java.sql.Date.valueOf(flight.getArrivalDate()));
			prepst.setTime(7, java.sql.Time.valueOf(flight.getArrivalTimings()));
			prepst.setDate(8, java.sql.Date.valueOf(flight.getDepartureDate()));
			prepst.setTime(9, java.sql.Time.valueOf(flight.getDepartureTimings()));

			prepst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException("unable to add");
		}
		return true;
	}

	@Override
	public boolean removeFlight(int flightId) {
		try (Connection connection = link.getConnection();
				PreparedStatement prepst = connection.prepareStatement(link.getQuery("removeingFlight"));) {
			prepst.setInt(1, flightId);
			int result = prepst.executeUpdate();
			if (result != 0) {
				return true;
			}

		} catch (Exception e) {
			throw new AirlineException(e.getMessage());

		}
		throw new AirlineException("It cant be removed ,as it is not there");
	}

	@Override
	public List<FlightBean> searchFlightBySource(String sourcePoint) {
		FlightBean flight = null;
		List<FlightBean> list = new ArrayList<FlightBean>();
		try (Connection connection = link.getConnection();
				PreparedStatement prepst = connection.prepareStatement(link.getQuery("flightBySource"));) {
			prepst.setString(1, sourcePoint);
			try (ResultSet result = prepst.executeQuery();) {
				if (result.next()) {
					flight = new FlightBean();
					flight.setFlightId(result.getInt("flightId"));
					flight.setFlightName(result.getString("flightName"));
					flight.setSourcePoint(result.getString("sourcePoint"));
					flight.setDeparturePoint(result.getString("departurePoint"));
					flight.setTotalSeatsAvailable(result.getInt("TotalSeatsAvailable"));
					flight.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
					flight.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
					flight.setDepartureDate(result.getDate("departureDate").toLocalDate());
					flight.setDepartureTimings(result.getTime("departureTimings").toLocalTime());
					list.add(flight);
					return list;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		}
		throw new AirlineException("Flight is Not Found in the Airline  with the Given Flight Source");

	}

	@Override
	public List<FlightBean> searchFlightByDepature(String depaturePoint) {
		FlightBean flight = null;
		List<FlightBean> list = new ArrayList<FlightBean>();
		try {
			Connection connection = link.getConnection();
			PreparedStatement prepst = connection.prepareStatement(link.getQuery("flightByDeparture"));
			prepst.setString(1, depaturePoint);
			try (ResultSet result = prepst.executeQuery();) {
				if (result.next()) {
					flight = new FlightBean();
					flight.setFlightId(result.getInt("flightId"));
					flight.setFlightName(result.getString("flightName"));
					flight.setSourcePoint(result.getString("sourcePoint"));
					flight.setDeparturePoint(result.getString("departurePoint"));
					flight.setTotalSeatsAvailable(result.getInt("totalSeatsAvailable"));
					flight.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
					flight.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
					flight.setDepartureDate(result.getDate("departureDate").toLocalDate());
					flight.setDepartureTimings(result.getTime("departureTimings").toLocalTime());
					list.add(flight);
					return list;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AirlineException(e.getMessage());
		}
		throw new AirlineException("Flight Not Present with this DeparturePoint");
	}

	@Override
	public List<FlightBean> getFlightDetails() {
		List<FlightBean> list = new LinkedList<FlightBean>();
		try (Connection connection = link.getConnection();
				Statement st = connection.createStatement();
				ResultSet result = st.executeQuery(link.getQuery("allFlights"))) {
			while (result.next()) {
				FlightBean info = new FlightBean();
				info.setFlightId(result.getInt("flightId"));
				info.setFlightName(result.getString("flightName"));
				info.setSourcePoint(result.getString("sourcePoint"));
				info.setDeparturePoint(result.getString("departurePOint"));
				info.setTotalSeatsAvailable(result.getInt("totalSeatsAvailable"));
				info.setArrivalDate(result.getDate("arrivalDate").toLocalDate());
				info.setArrivalTimings(result.getTime("arrivalTimings").toLocalTime());
				info.setDepartureDate(result.getDate("departureDate").toLocalDate());
				info.setDepartureTimings(result.getTime("departureTimings").toLocalTime());

				list.add(info);
			}
			if (list.isEmpty()) {
				throw new AirlineException("No Flight Present in the Airline");
			} else {
				return list;
			}
		} catch (Exception e) {
			throw new AirlineException(e.getMessage());
		}
	}

	@Override
	public List<StatusBean> getFlightBookingStatus() {
		List<StatusBean> list = new LinkedList<StatusBean>();
		try (Connection connection = link.getConnection();
				Statement st = connection.createStatement();
				ResultSet result = st.executeQuery(link.getQuery("showBooking"))) {
			while (result.next()) {
				StatusBean status = new StatusBean();
				status.setBookingId(result.getInt("bookingId"));
				status.setFlightId(result.getInt("flightId"));
				status.setId(result.getInt("id"));
				status.setTotalSeatsBooked(result.getInt("totalSeatsBooked"));

				list.add(status);
			}
			if (list.isEmpty()) {
				throw new AirlineException("No  Status Present ");
			} else {
				return list;
			}
		} catch (Exception e) {
			throw new AirlineException(e.getMessage());
		}
	}

}